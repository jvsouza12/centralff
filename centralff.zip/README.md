# FF DO 100 / MODESTO

Gestão do FF do 100 no modo FF — Free Faca; clã SenSaTIOnN. Projeto não oficial, sem vínculo com CrossFire/Z8Games.

## Autenticação de jogador (própria do projeto)
O acesso de jogador usa o **autenticador próprio do projeto** (`src/lib/player-auth.ts`), apoiado apenas no Supabase deste projeto: nick + e-mail + senha, com reenvio do e-mail de ativação, recuperação por e-mail e definição de nova senha. O login social intermediado do Lovable (`@lovable.dev/cloud-auth-js`), o broker de sessão de preview e a telemetria do Lovable foram removidos: a sessão fica somente no `localStorage` deste domínio.

- `src/lib/player-auth.ts`: entrar, criar acesso, reenviar ativação, recuperar e trocar senha (validação Zod + mensagens em português) e leitura dos links de e-mail (`hasAuthLinkParams`, `readAuthLinkFeedback`).
- `src/components/PlayerAuthForm.tsx`: abas Entrar / Criar acesso / Recuperar no portal, com reenvio de ativação na aba Entrar.
- `/redefinir-senha`: conclui a redefinição a partir do link enviado por e-mail, inclusive quando o provedor devolve o erro na URL.
- `/arena` e `/cadastro`: área do jogador com “Alterar senha” autenticado (não depende de e-mail) e nome da sala oficial.

**Configuração necessária no painel do Supabase (Authentication):** habilitar o provedor Email, definir o Site URL e a lista de Redirect URLs incluindo `https://<seu-domínio>`, `https://<seu-domínio>/arena` e `https://<seu-domínio>/redefinir-senha` (mais `http://localhost:<porta>` no desenvolvimento). Sem isso o cadastro e a recuperação não concluem.

## Rotas
- `/`: portal público dos jogadores; a marca MODESTO abre `/modesto`.
- `/modesto`: autenticação ADM separada.
- `/admin`: controle diário, jogadores, fila e ranking VIP; todas as operações verificam a sessão ADM no servidor.
- `/cadastro`: formulário protegido pelo acesso de jogador; `/arena` preserva o endereço histórico e mostra o mesmo formulário.
- `/redefinir-senha`: define nova senha após o link de recuperação.
- `/lista-espera`: encaminha ao acesso protegido; não exibe fila pública.
- `/api/health`: saúde sem dados pessoais. `/api/public/health` é o endereço público canônico para a hospedagem gerenciada (o prefixo `/api/public/` evita a proteção automática da hospedagem).

## Dados e segurança
Migrações aditivas em `drizzle/migrations/`; não executar limpeza ou semeadura. Nenhum jogador, sessão, telefone, ocorrência, declaração ou item de fila é criado automaticamente. Registros e fila são independentes; aprovação ADM vincula participante sem criar horas.

Telefone/consentimento nunca são retornados na consulta de jogador e são carregados no ADM apenas ao abrir a ficha. Sessões ADM: tokens opacos aleatórios em cookies HttpOnly, hash HMAC persistido, 8 horas e revogação no logout; HTTPS externo usa Secure/SameSite=None, HTTP local usa Lax. IP de novas tentativas é armazenado como hash com chave. Cinco falhas em 15 minutos bloqueiam acesso através de operação atômica; tentativas com mais de 30 dias e sessões expiradas são limpas durante login. CSRF do TanStack permanece habilitado para server functions. Leituras privadas usam no-store/private.

Operações críticas são transacionais; uma sessão aberta por participante, versões de edição, fila com bloqueio compartilhado, idempotência de confirmação e ocorrências. Polling de 5 segundos no ADM; relógios calculados no navegador, sem gravações por segundo. Data civil America/Sao_Paulo. Desfazer saída disponível por 30 segundos, inclusive após atualização. Correções ADM adicionam tempo explicitamente identificado sem reescrever intervalos reais. Sessões iniciadas antes da meia-noite pertencem ao dia civil do início; não são redistribuídas automaticamente para outro dia.

## Variáveis
| Nome | Uso |
|---|---|
| ADMIN_LOGIN | Credencial ADM somente servidor |
| ADMIN_PASSWORD | Senha ADM; substituir a senha temporária por uma senha forte antes de publicar |
| ADMIN_SESSION_SECRET | Chave para hashes de sessão e tentativas; alterar invalida sessões atuais |
| SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY / SUPABASE_SERVICE_ROLE_KEY | Configuração gerenciada do servidor, nunca expor ao navegador |
| VITE_SUPABASE_URL / VITE_SUPABASE_PUBLISHABLE_KEY | Configuração pública gerenciada do navegador |
| VITE_ERROR_ENDPOINT | Opcional: coletor próprio para relatórios de erro do frontend |
| APP_CRON_SECRET / APP_CRON_SECRET_PREVIOUS | Opcional: protege tarefas agendadas próprias (`src/integrations/supabase/cron-auth.ts`) |

Crie `ADMIN_LOGIN`, `ADMIN_PASSWORD` e `ADMIN_SESSION_SECRET` como secrets do ambiente de execução (Lovable Cloud → Secrets, ou o painel de secrets do provedor). Não inserir valores reais no repositório. A troca do formato anterior de cookie exige novo login ADM, mas não remove dados legítimos.

## Execução e publicação
`bun install`, `bun run dev` (Vite usa PORT/porta configurada pela hospedagem), `bun run test`, `bun run build`. A hospedagem gerenciada fornece frontend, funções de servidor e banco; publicação pelo Lovable. Migrações devem ser aplicadas pela ferramenta gerenciada, não executadas novamente manualmente.

**Limite em relação ao documento recebido:** este projeto usa React/TypeScript/TanStack Start com Lovable Cloud PostgreSQL, não Express/MySQL. Não foi criado adaptador Netlify nem banco MySQL; publicar somente arquivos estáticos na Netlify não faria as funções funcionarem. Uma migração externa precisaria de ambiente de execução compatível, variáveis protegidas, conexão TLS, estratégia de migrações e verificação do domínio e APIs nesse ambiente. Nenhum deploy externo foi realizado.

## Verificação e pendências externas
Testes de regras em `src/test/operations.test.ts`, do autenticador próprio em `src/test/player-auth.test.ts`, dos links de e-mail em `src/test/auth-links.test.ts` e das rotas em `src/test/app-routing.test.tsx`; teste de transação em `src/test/operations.database.test.ts` requer conexão autorizada a assumir service_role, caso contrário é pulado sem ampliar privilégios. O login do jogador agora é o autenticador próprio do projeto (e-mail/senha + reenvio de ativação + recuperação); habilite o provedor Email e as Redirect URLs no painel do Supabase antes de publicar. Consulte `AUDIT.md` para resultados, limites e arquivos modificados.
