// DESATIVADO — o autenticador do projeto (src/lib/player-auth.ts) substituiu o
// Lovable Cloud Auth e a dependência @lovable.dev/cloud-auth-js foi removida.
// Este módulo não é importado pelo app.
export {};

