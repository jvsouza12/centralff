export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admin_login_attempts: {
        Row: {
          created_at: string
          id: string
          ip: string
          success: boolean
        }
        Insert: {
          created_at?: string
          id?: string
          ip: string
          success?: boolean
        }
        Update: {
          created_at?: string
          id?: string
          ip?: string
          success?: boolean
        }
        Relationships: []
      }
      ff_admin_sessions: {
        Row: {
          created_at: string
          expires_at: string
          login: string
          token_hash: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          login: string
          token_hash: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          login?: string
          token_hash?: string
        }
        Relationships: []
      }
      ff_daily_notes: {
        Row: {
          correction_seconds: number
          day: string
          note: string
          participant_id: string
          version: number
        }
        Insert: {
          correction_seconds?: number
          day: string
          note?: string
          participant_id: string
          version?: number
        }
        Update: {
          correction_seconds?: number
          day?: string
          note?: string
          participant_id?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "ff_daily_notes_participant_id_fkey"
            columns: ["participant_id"]
            isOneToOne: false
            referencedRelation: "ff_participants"
            referencedColumns: ["id"]
          },
        ]
      }
      ff_daily_sessions: {
        Row: {
          day: string
          ended_at: string | null
          id: string
          participant_id: string
          started_at: string
          version: number
        }
        Insert: {
          day: string
          ended_at?: string | null
          id?: string
          participant_id: string
          started_at?: string
          version?: number
        }
        Update: {
          day?: string
          ended_at?: string | null
          id?: string
          participant_id?: string
          started_at?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "ff_daily_sessions_participant_id_fkey"
            columns: ["participant_id"]
            isOneToOne: false
            referencedRelation: "ff_participants"
            referencedColumns: ["id"]
          },
        ]
      }
      ff_incidents: {
        Row: {
          created_at: string
          description: string
          evidence: string
          happened_on: string
          id: string
          registration_id: string
          request_key: string
        }
        Insert: {
          created_at?: string
          description: string
          evidence?: string
          happened_on: string
          id?: string
          registration_id: string
          request_key: string
        }
        Update: {
          created_at?: string
          description?: string
          evidence?: string
          happened_on?: string
          id?: string
          registration_id?: string
          request_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "ff_incidents_registration_id_fkey"
            columns: ["registration_id"]
            isOneToOne: false
            referencedRelation: "ff_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      ff_participants: {
        Row: {
          created_at: string
          id: string
          nick: string
          nick_key: string | null
          registration_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          nick: string
          nick_key?: string | null
          registration_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          nick?: string
          nick_key?: string | null
          registration_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ff_participants_registration_id_fkey"
            columns: ["registration_id"]
            isOneToOne: true
            referencedRelation: "ff_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      ff_registrations: {
        Row: {
          auto_on: boolean
          consent: boolean
          consent_at: string
          id: string
          nick: string
          nick_key: string | null
          phone: string
          status: string
          submitted_at: string
          user_id: string
          version: number
          vip: number
        }
        Insert: {
          auto_on: boolean
          consent: boolean
          consent_at?: string
          id?: string
          nick: string
          nick_key?: string | null
          phone: string
          status?: string
          submitted_at?: string
          user_id: string
          version?: number
          vip: number
        }
        Update: {
          auto_on?: boolean
          consent?: boolean
          consent_at?: string
          id?: string
          nick?: string
          nick_key?: string | null
          phone?: string
          status?: string
          submitted_at?: string
          user_id?: string
          version?: number
          vip?: number
        }
        Relationships: []
      }
      ff_submission_limits: {
        Row: {
          last_at: string
          user_id: string
        }
        Insert: {
          last_at?: string
          user_id: string
        }
        Update: {
          last_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ff_waitlist: {
        Row: {
          created_at: string
          id: string
          nick: string
          nick_key: string | null
          position: number
          version: number
        }
        Insert: {
          created_at?: string
          id?: string
          nick: string
          nick_key?: string | null
          position?: never
          version?: number
        }
        Update: {
          created_at?: string
          id?: string
          nick?: string
          nick_key?: string | null
          position?: never
          version?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      ff_admin_operation: {
        Args: { command: string; payload: Json }
        Returns: Json
      }
      ff_record_login_attempt: {
        Args: { p_ip: string; p_success: boolean }
        Returns: boolean
      }
      ff_submit_registration: {
        Args: {
          p_auto: boolean
          p_consent: boolean
          p_nick: string
          p_phone: string
          p_vip: number
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
