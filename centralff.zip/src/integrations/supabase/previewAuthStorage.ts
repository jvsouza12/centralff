// DESATIVADO — a sessão do autenticador do projeto é guardada apenas no
// localStorage deste domínio (ver src/integrations/supabase/client.ts).
// O compartilhamento de sessão entre superfícies de preview do Lovable foi
// removido; nenhum código importa este módulo.
export function brokeredPreviewStorage() {
  if (typeof window === 'undefined') return undefined;
  return window.localStorage;
}
