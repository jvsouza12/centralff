import { createFileRoute, Link, redirect, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Eye, EyeOff, Loader2, Lock, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Brand } from "@/components/Brand";
import { adminLogin, getAdminSession } from "@/lib/admin.functions";

export const Route = createFileRoute("/adm")({
  head: () => ({
    meta: [
      { title: "Acesso ADM — FF do 100 | SenSaTIOnN" },
      {
        name: "description",
        content: "Autenticação administrativa independente do portal de jogadores do FF do 100.",
      },
      { property: "og:title", content: "Acesso ADM — FF do 100" },
      { property: "og:description", content: "Área restrita dos administradores do FF do 100." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  // Sessão ADM ainda válida: não faz sentido pedir login novamente.
  beforeLoad: async () => {
    const session = await getAdminSession();
    if (session) throw redirect({ to: "/admin" });
  },
  component: AdminAccess,
});

function AdminAccess() {
  const navigate = useNavigate();
  const signIn = useServerFn(adminLogin);
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (busy) return;
    if (!login.trim() || !password) {
      setError("Preencha login e senha.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await signIn({ data: { login, password } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setPassword("");
      await navigate({ to: "/admin" });
    } catch {
      setError("Não foi possível entrar. Tente novamente.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-5 py-12">
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-tactical-grid opacity-40" />
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-scanlines opacity-20" />

      <div className="animate-rise relative z-10 w-full max-w-sm">
        <Link
          to="/"
          aria-label="Voltar ao portal de jogadores"
          className="inline-flex transition-opacity hover:opacity-90"
        >
          <Brand size="sm" />
        </Link>

        <div className="clip-tactical relative mt-8 border border-border bg-card p-7 shadow-panel sm:p-8">
          <span aria-hidden className="absolute inset-x-0 top-0 h-1 bg-hazard opacity-80" />
          <span className="inline-flex h-11 w-11 items-center justify-center border border-primary/50 bg-primary/10 text-primary">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <h1 className="mt-5 font-display text-4xl uppercase tracking-[0.06em] text-foreground">
            Acesso <span className="text-primary">ADM</span>
          </h1>
          <p className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
            <Lock className="h-3.5 w-3.5" />
            Área restrita · credenciais independentes do jogador
          </p>

          <form className="mt-7 space-y-5" onSubmit={submit} noValidate>
            <div className="space-y-2">
              <Label
                htmlFor="adm-login"
                className="font-display text-[11px] uppercase tracking-[0.28em] text-metal"
              >
                Login ADM
              </Label>
              <Input
                id="adm-login"
                className="h-12 bg-background/60"
                value={login}
                maxLength={64}
                onChange={(e) => setLogin(e.target.value)}
                autoComplete="username"
                required
              />
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="adm-password"
                className="font-display text-[11px] uppercase tracking-[0.28em] text-metal"
              >
                Senha ADM
              </Label>
              <div className="relative">
                <Input
                  id="adm-password"
                  className="h-12 bg-background/60 pr-12 font-mono"
                  type={show ? "text" : "password"}
                  value={password}
                  maxLength={128}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  required
                />
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  className="absolute right-1 top-1.5"
                  aria-label={show ? "Ocultar senha" : "Mostrar senha"}
                  title={show ? "Ocultar senha" : "Mostrar senha"}
                  onClick={() => setShow((v) => !v)}
                >
                  {show ? <EyeOff /> : <Eye />}
                </Button>
              </div>
            </div>

            {error && (
              <p role="alert" className="border-l-2 border-destructive pl-3 text-sm text-destructive">
                {error}
              </p>
            )}

            <Button
              className="h-14 w-full gap-3"
              variant="tactical"
              type="submit"
              disabled={busy}
              aria-busy={busy}
            >
              {busy ? (
                <>
                  <Loader2 className="animate-spin" />
                  Validando…
                </>
              ) : (
                "Entrar no painel"
              )}
            </Button>
          </form>
        </div>

        <Button asChild className="mt-5 w-full" variant="ghost">
          <Link to="/">
            <ArrowLeft />
            Voltar ao portal de jogadores
          </Link>
        </Button>
      </div>
    </main>
  );
}
