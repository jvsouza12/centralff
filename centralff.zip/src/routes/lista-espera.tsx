import { createFileRoute, redirect } from '@tanstack/react-router'
import { getAdminSession } from '@/lib/admin.functions'
export const Route = createFileRoute('/lista-espera')({
  head: () => ({ meta: [{ title: 'Fila privada — FF DO 100' }, { name: 'description', content: 'A fila do FF do 100 é exclusiva para administradores autenticados.' }, { property: 'og:title', content: 'Fila privada — FF DO 100' }, { property: 'og:description', content: 'Fila operacional restrita.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }, { name: 'robots', content: 'noindex, nofollow' }] }),
  beforeLoad: async () => { const session = await getAdminSession(); throw redirect({ to: session ? '/admin' : '/adm' }) },
})