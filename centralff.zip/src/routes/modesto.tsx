import { createFileRoute, Link, redirect, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { useServerFn } from '@tanstack/react-start'
import { Eye, EyeOff, ShieldCheck, Loader2, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Brand } from '@/components/Brand'
import { adminLogin, getAdminSession } from '@/lib/admin.functions'

export const Route = createFileRoute('/modesto')({
  head: () => ({ meta: [{ title: 'Acesso ADM — FF do 100' }, { name: 'description', content: 'Autenticação administrativa independente do portal de jogadores do FF do 100.' }, { property: 'og:title', content: 'Acesso ADM — FF do 100' }, { property: 'og:description', content: 'Portal restrito dos administradores do FF do 100.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }, { name: 'robots', content: 'noindex, nofollow' }] }),
  // Rota legada: mantida só para não quebrar links antigos. O acesso ADM agora é /adm.
  beforeLoad: async () => {
    const session = await getAdminSession()
    throw redirect({ to: session ? '/admin' : '/adm' })
  },
  component: AdminAccess,
})
function AdminAccess() {
  const navigate = useNavigate(), signIn = useServerFn(adminLogin)
  const [login, setLogin] = useState(''), [password, setPassword] = useState(''), [show, setShow] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState('')
  return <main className="flex min-h-screen flex-col items-center justify-center bg-background px-5 py-12"><div className="w-full max-w-sm"><Brand /><div className="mt-10 border-t-2 border-primary pt-6"><ShieldCheck className="mb-4 h-7 w-7 text-primary" /><h2 className="font-display text-3xl">Acesso administrativo</h2><p className="mt-2 text-sm text-muted-foreground">Credenciais ADM independentes do acesso de jogadores.</p><form className="mt-6 space-y-5" onSubmit={async e => { e.preventDefault(); if (busy) return; if (!login.trim() || !password) { setError('Preencha login e senha.'); return } setBusy(true); setError(''); try { const result = await signIn({ data: { login, password } }); if (!result.ok) { setError(result.error); return } setPassword(''); await navigate({ to: '/admin' }) } catch { setError('Não foi possível entrar. Tente novamente.') } finally { setBusy(false) } }}><div><Label htmlFor="modesto-login">Login ADM</Label><Input className="mt-2 h-12" id="modesto-login" value={login} maxLength={64} onChange={e => setLogin(e.target.value)} autoComplete="username" required /></div><div><Label htmlFor="modesto-password">Senha ADM</Label><div className="relative mt-2"><Input className="h-12 pr-12" id="modesto-password" type={show ? 'text' : 'password'} value={password} maxLength={128} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required /><Button type="button" size="icon" variant="ghost" className="absolute right-1 top-1.5" aria-label={show ? 'Ocultar senha' : 'Mostrar senha'} title={show ? 'Ocultar senha' : 'Mostrar senha'} onClick={() => setShow(v => !v)}>{show ? <EyeOff /> : <Eye />}</Button></div></div>{error && <p role="alert" className="text-sm text-destructive">{error}</p>}<Button className="h-12 w-full" variant="tactical" type="submit" disabled={busy}>{busy ? <><Loader2 className="animate-spin" />Validando…</> : 'Entrar no painel'}</Button></form><Button asChild className="mt-5 w-full" variant="ghost"><Link to="/"><ArrowLeft />Voltar ao portal de jogadores</Link></Button></div></div></main>
}