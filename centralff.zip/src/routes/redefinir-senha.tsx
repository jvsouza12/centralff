import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { KeyRound, Loader2, ShieldAlert, ShieldCheck, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Brand } from "@/components/Brand";
import { supabase } from "@/integrations/supabase/client";
import {
  clearRecoveryIntent,
  markRecoveryIntent,
  readAuthLinkFeedback,
  setNewPlayerPassword,
} from "@/lib/player-auth";

export const Route = createFileRoute("/redefinir-senha")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Redefinir senha — FF do 100 | SenSaTIOnN" },
      { name: "description", content: "Definição de nova senha do acesso de jogador do clã SenSaTIOnN." },
      { property: "og:title", content: "Redefinir senha — FF DO 100" },
      { property: "og:description", content: "Área privada de redefinição de senha do jogador." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [recovery, setRecovery] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [linkError, setLinkError] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    // O provedor pode devolver o motivo da falha direto na URL do link.
    const feedback = readAuthLinkFeedback();
    if (feedback?.kind === "error") setLinkError(feedback.message);
    if (feedback?.kind === "recovery") markRecoveryIntent();
  }, []);

  useEffect(() => {
    let alive = true;
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (!alive) return;
      if (event === "PASSWORD_RECOVERY" || session) {
        setRecovery(true);
        setChecking(false);
        // O usuário já está na tela de nova senha: a marcação de intenção não é
        // mais necessária e não deve bloquear outros acessos.
        clearRecoveryIntent();
        if (typeof window !== "undefined" && window.location.hash)
          window.history.replaceState(null, "", window.location.pathname);
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      if (!alive) return;
      if (data.session) {
        setRecovery(true);
        clearRecoveryIntent();
        if (typeof window !== "undefined" && window.location.hash)
          window.history.replaceState(null, "", window.location.pathname);
      }
      setChecking(false);
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (busy) return;
    setError("");
    if (password !== confirm) {
      setError("As senhas não coincidem.");
      return;
    }
    setBusy(true);
    const result = await setNewPlayerPassword({ password });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setPassword("");
    setConfirm("");
    setDone(true);
    toast.success(result.message ?? "Senha atualizada.");
    setTimeout(() => {
      void supabase.auth.signOut().finally(() => navigate({ to: "/", replace: true }));
    }, 1800);
  }

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-background px-5 py-12">
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-tactical-grid opacity-40" />
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-scanlines opacity-20" />
      <div className="animate-rise relative z-10 w-full max-w-sm">
        <Link
          to="/"
          aria-label="Voltar ao portal de jogadores"
          className="inline-flex transition-opacity hover:opacity-90"
        >
          <Brand size="sm" />
        </Link>
        <div className="clip-tactical relative mt-8 border border-border bg-card p-7 shadow-panel sm:p-8">
          <span aria-hidden className="absolute inset-x-0 top-0 h-1 bg-hazard opacity-80" />
          <span className="inline-flex h-11 w-11 items-center justify-center border border-primary/50 bg-primary/10 text-primary">
            <KeyRound className="h-5 w-5" />
          </span>
          <h1 className="mt-5 font-display text-4xl uppercase tracking-[0.06em] text-foreground">
            Nova <span className="text-primary">senha</span>
          </h1>
          {linkError && !checking && !done && recovery && (
            <p
              role="alert"
              className="mt-4 flex items-start gap-2 border-l-2 border-destructive pl-3 text-sm text-destructive"
            >
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
              {linkError}
            </p>
          )}
          {checking ? (
            <p className="mt-4 flex items-center gap-2 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Validando o link recebido…
            </p>
          ) : done ? (
            <div className="mt-4 space-y-4" aria-live="polite">
              <p className="flex items-center gap-2 text-success">
                <ShieldCheck className="h-5 w-5" /> Senha atualizada com sucesso.
              </p>
              <p className="text-sm text-muted-foreground">
                Você será encaminhado ao portal para entrar com a nova senha.
              </p>
              <Button asChild variant="tactical" className="h-12 w-full">
                <Link to="/">Ir para o portal</Link>
              </Button>
            </div>
          ) : recovery ? (
            <form className="mt-6 space-y-5" onSubmit={submit} noValidate>
              <p className="text-sm text-muted-foreground">
                Defina uma nova senha com pelo menos 8 caracteres. Ao concluir, este acesso será
                encerrado e você entrará novamente com a senha nova.
              </p>
              <div>
                <Label htmlFor="reset-password">Nova senha</Label>
                <Input
                  id="reset-password"
                  className="mt-2 h-12 font-mono"
                  type="password"
                  autoComplete="new-password"
                  minLength={8}
                  maxLength={72}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="reset-confirm">Repetir nova senha</Label>
                <Input
                  id="reset-confirm"
                  className="mt-2 h-12 font-mono"
                  type="password"
                  autoComplete="new-password"
                  minLength={8}
                  maxLength={72}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  required
                />
              </div>
              {error && (
                <p role="alert" className="flex items-center gap-2 text-sm text-destructive">
                  <ShieldAlert className="h-4 w-4" /> {error}
                </p>
              )}
              <Button variant="tactical" className="h-12 w-full" type="submit" disabled={busy} aria-busy={busy}>
                {busy ? (
                  <>
                    <Loader2 className="animate-spin" /> Salvando…
                  </>
                ) : (
                  "SALVAR NOVA SENHA"
                )}
              </Button>
            </form>
          ) : (
            <div className="mt-4 space-y-4">
              <p role="alert" className="flex items-start gap-2 text-sm text-destructive">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
                {linkError || "Link inválido ou expirado. Solicite uma nova redefinição no portal."}
              </p>
              <Button asChild variant="tactical" className="h-12 w-full">
                <Link to="/" onClick={() => clearRecoveryIntent()}>
                  Solicitar novo link
                </Link>
              </Button>
            </div>
          )}
        </div>
        <Button asChild className="mt-5 w-full" variant="ghost">
          <Link to="/">
            <ArrowLeft /> Voltar ao portal de jogadores
          </Link>
        </Button>
      </div>
    </main>
  );
}
