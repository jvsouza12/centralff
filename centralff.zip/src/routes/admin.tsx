import { createFileRoute, redirect } from '@tanstack/react-router'
import { getAdminSession } from '@/lib/admin.functions'
import { ManagementPanel } from '@/components/ManagementPanel'
export const Route = createFileRoute('/admin')({
  head: () => ({ meta: [{ title: 'Operação ADM — FF do 100 | SenSaTIOnN' }, { name: 'description', content: 'Gestão privada de jogadores, controle diário, fila e ranking VIP do FF do 100.' }, { property: 'og:title', content: 'Operação ADM — FF do 100' }, { property: 'og:description', content: 'Área administrativa privada do FF do 100.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }, { name: 'robots', content: 'noindex, nofollow' }] }),
  beforeLoad: async () => { const admin = await getAdminSession(); if (!admin) throw redirect({ to: '/adm' }); return { admin } },
  component: AdminPage,
})
function AdminPage() { const { admin } = Route.useRouteContext(); return <ManagementPanel login={admin.login} /> }
