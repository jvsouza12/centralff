import { createFileRoute, redirect } from "@tanstack/react-router";
import { PlayerRegistration } from "@/components/PlayerRegistration";
import { supabase } from "@/integrations/supabase/client";
import { hasAuthLinkParams, hasRecoveryIntent, readAuthLinkFeedback } from "@/lib/player-auth";

export const Route = createFileRoute("/arena")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Área do jogador — FF do 100 · SenSaTIOnN" },
      { name: "description", content: "Cadastro e status do jogador no FF do 100, clã SenSaTIOnN." },
      { property: "og:title", content: "Área do jogador — FF do 100 · SenSaTIOnN" },
      { property: "og:description", content: "Cadastro e status do jogador no FF do 100, clã SenSaTIOnN." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  beforeLoad: async () => {
    const recoveryLink = readAuthLinkFeedback()?.kind === "recovery";
    const recoveryIntent = hasAuthLinkParams() && hasRecoveryIntent();
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) {
      if (recoveryLink) throw redirect({ to: "/redefinir-senha" });
      throw redirect({ to: "/" });
    }
    // Um link de recuperação não pode abrir a área do jogador antes da nova senha.
    if (recoveryLink || recoveryIntent) throw redirect({ to: "/redefinir-senha" });
    return { user: data.user };
  },
  component: Arena,
});

function Arena() {
  return <PlayerRegistration />;
}
