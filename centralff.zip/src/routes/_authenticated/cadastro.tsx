import { createFileRoute } from '@tanstack/react-router'
import { PlayerRegistration } from '@/components/PlayerRegistration'
export const Route = createFileRoute('/_authenticated/cadastro')({
  head: () => ({     meta: [{ title: 'Meu cadastro — FF do 100 | SenSaTIOnN' }, { name: 'description', content: 'Cadastro privado do jogador para FF — Free Faca.' }, { property: 'og:title', content: 'Meu cadastro — FF do 100' }, { property: 'og:description', content: 'Cadastro e estado individual do jogador.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }, { name: 'robots', content: 'noindex, nofollow' }] }),
  component: PlayerRegistration,
})