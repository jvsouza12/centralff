import { createFileRoute, Outlet, redirect } from '@tanstack/react-router'
import { supabase } from '@/integrations/supabase/client'
import { hasAuthLinkParams, hasRecoveryIntent, readAuthLinkFeedback } from '@/lib/player-auth'
export const Route = createFileRoute('/_authenticated')({
  ssr: false,
  beforeLoad: async () => {
    const recoveryLink = readAuthLinkFeedback()?.kind === "recovery";
    const recoveryIntent = hasAuthLinkParams() && hasRecoveryIntent();
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) {
      if (recoveryLink) throw redirect({ to: "/redefinir-senha" });
      throw redirect({ to: "/" });
    }
    if (recoveryLink || recoveryIntent) throw redirect({ to: "/redefinir-senha" });
    return { user: data.user };
  },
  component: Outlet,
})