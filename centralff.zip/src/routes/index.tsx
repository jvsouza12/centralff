import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Crosshair, ListOrdered, Lock, ShieldCheck, Swords, Users } from "lucide-react";
import { toast } from "sonner";
import { DISCORD_INVITE } from "@/lib/operations";
import { Button } from "@/components/ui/button";
import { Brand } from "@/components/Brand";
import { PlayerAuthForm } from "@/components/PlayerAuthForm";
import { supabase } from "@/integrations/supabase/client";
import { hasAuthLinkParams, hasRecoveryIntent, readAuthLinkFeedback } from "@/lib/player-auth";
import { roomName } from "@/lib/operations";
import hero from "@/assets/hero-soldiers.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FF do 100 | SenSaTIOnN" },
      { name: "description", content: "Central do clã SenSaTIOnN no modo FF — Free Faca do CrossFire: cadastro, controle diário, fila de espera e ranking VIP." },
      { property: "og:title", content: "FF do 100 | SenSaTIOnN" },
      { property: "og:description", content: "Portal de jogadores do clã SenSaTIOnN." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LoginPage,
});

const PARTICLES = Array.from({ length: 18 }, (_, i) => ({
  left: `${(i * 37) % 100}%`,
  delay: `${(i * 1.3) % 12}s`,
  duration: `${10 + ((i * 7) % 10)}s`,
}));

function LoginPage() {
  const navigate = useNavigate();

  useEffect(() => {
    // Links de e-mail (confirmação de cadastro, recuperação e falhas) chegam aqui
    // enquanto o portal ainda está montado.
    const linkParams = hasAuthLinkParams();
    const feedback = readAuthLinkFeedback();
    // A intenção de recuperação só vale quando o acesso chega por um link de e-mail:
    // evita prender um jogador já autenticado na tela de nova senha.
    const recoveryPending =
      feedback?.kind === "recovery" || (linkParams && hasRecoveryIntent());
    let recoverySeen = recoveryPending;
    if (feedback) {
      if (feedback.kind === "error") toast.error(feedback.message);
      else toast.success(feedback.message);
    }
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) return;
      if (event === "PASSWORD_RECOVERY" || readAuthLinkFeedback()?.kind === "recovery") {
        recoverySeen = true;
        void navigate({ to: "/redefinir-senha", replace: true });
        return;
      }
      if (recoverySeen) {
        void navigate({ to: "/redefinir-senha", replace: true });
        return;
      }
      // Confirmação de e-mail: mostra o aviso antes de entrar na área do jogador.
      if (linkParams) {
        window.setTimeout(() => void navigate({ to: "/arena", replace: true }), 1500);
        return;
      }
      void navigate({ to: "/arena", replace: true });
    });
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) return;
      if (recoverySeen) {
        void navigate({ to: "/redefinir-senha", replace: true });
        return;
      }
      if (!linkParams) {
        void navigate({ to: "/arena", replace: true });
        return;
      }
      // Fluxo PKCE (?code=…): confirma o acesso somente se não for recuperação.
      window.setTimeout(() => {
        if (recoverySeen) return;
        if (!feedback) toast.success("Acesso confirmado. Bem-vindo ao portal do jogador.");
        void navigate({ to: "/arena", replace: true });
      }, 1500);
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  const features = [
    { icon: Crosshair, title: "Controle diário", text: "Marcação de entradas e saídas por data." },
    { icon: Users, title: "Cadastro do jogador", text: "Auto ON, armas VIP e regras do grupo." },
    { icon: ListOrdered, title: "Fila de espera", text: "Ordem de entrada das partidas." },
  ] as const;

  return (
    <main className="relative min-h-screen overflow-hidden bg-background">
      <img
        src={hero}
        alt=""
        width={1920}
        height={1088}
        className="pointer-events-none absolute inset-0 h-full w-full object-cover object-center opacity-40"
      />
      <div className="absolute inset-0 bg-vignette" />
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-tactical-grid opacity-50" />
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-scanlines opacity-25" />
      <div aria-hidden className="pointer-events-none absolute inset-0">
        {PARTICLES.map((p, i) => (
          <span key={i} className="animate-drift absolute bottom-0 h-1 w-1 rounded-full bg-primary-glow"
            style={{ left: p.left, animationDelay: p.delay, animationDuration: p.duration }} />
        ))}
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-7xl flex-col px-5 py-6 sm:px-8 lg:py-8">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-4">
          <Link to="/" aria-label="Início" className="transition-opacity hover:opacity-90">
            <Brand size="sm" />
          </Link>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-2 font-display text-[11px] uppercase tracking-[0.28em] text-muted-foreground sm:inline-flex">
              <span className="animate-pulse-dot h-2 w-2 rounded-full bg-success" />
              Operação ativa
            </span>
            <Button asChild variant="outline" size="sm" className="h-10 gap-2 border-border bg-background/70 px-4">
              <Link to="/adm" aria-label="Acesso administrativo">
                <ShieldCheck className="h-4 w-4" />
                ADM
              </Link>
            </Button>
          </div>
        </header>

        <div className="grid flex-1 items-center gap-12 py-10 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,26rem)] lg:gap-16 lg:py-14">
          <section className="animate-rise">
            <p className="clip-banner inline-flex items-center gap-3 border border-primary/45 bg-primary/10 px-4 py-2 font-display text-[11px] uppercase tracking-[0.34em] text-primary-glow">
              <Swords className="h-4 w-4" />
              Modo FF · Free Faca
            </p>
            <h1 className="mt-6 font-display font-bold uppercase leading-[0.9] tracking-[0.02em] text-foreground">
              <span className="block text-5xl sm:text-6xl lg:text-7xl">
                SenSa<span className="text-primary">TIOnN</span>
              </span>
              <span className="mt-2 block text-3xl tracking-[0.16em] text-metal lg:text-4xl">
                FF do 100 · 24/48
              </span>
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              Central operacional do clã{" "}
              <strong className="font-semibold text-foreground">SenSaTIOnN</strong>: cadastro do
              jogador, controle diário de presença, fila de espera e ranking VIP em um só lugar.
            </p>

            <dl className="mt-9 grid grid-cols-2 gap-px border border-border bg-border">
              <div className="bg-background/85 p-4">
                <dt className="font-display text-[11px] uppercase tracking-[0.28em] text-metal">
                  Sala oficial
                </dt>
                <dd className="mt-2 break-words font-mono text-sm text-foreground">{roomName}</dd>
              </div>
              <div className="bg-background/85 p-4">
                <dt className="font-display text-[11px] uppercase tracking-[0.28em] text-metal">Clã</dt>
                <dd className="mt-2 font-display text-xl uppercase tracking-[0.08em] text-foreground">
                  SenSaTIOnN
                </dd>
              </div>
            </dl>

            <ul className="mt-9 grid gap-4 sm:grid-cols-3">
              {features.map(({ icon: Icon, title, text }) => (
                <li key={title} className="border-t-2 border-primary/60 bg-card/60 p-4">
                  <Icon className="h-5 w-5 text-primary" />
                  <p className="mt-3 font-display text-lg uppercase tracking-[0.08em] text-foreground">
                    {title}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{text}</p>
                </li>
              ))}
            </ul>
          </section>

          <section className="animate-rise clip-tactical relative border border-border bg-card p-6 shadow-panel backdrop-blur-md sm:p-8">
            <span aria-hidden className="absolute inset-x-0 top-0 h-1 bg-hazard opacity-80" />
            <div className="mb-6 flex items-center gap-3">
              <span className="h-9 w-1 bg-primary" />
              <div>
                <p className="font-display text-2xl uppercase tracking-[0.08em] text-foreground">
                  Portal do jogador
                </p>
                <p className="font-display text-[11px] uppercase tracking-[0.3em] text-metal">
                  Acesso restrito · FF do 100
                </p>
              </div>
            </div>
            <PlayerAuthForm />
            <p className="mt-6 border-t border-border pt-4 text-center text-xs text-muted-foreground">
              Projeto de comunidade não oficial. Sem vínculo com a desenvolvedora do CrossFire.
            </p>
          </section>
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4 text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} SenSaTIOnN · FF do 100</span>
          <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 font-semibold text-primary transition-colors hover:text-primary-glow">Discord do clã</a>
          <Link to="/adm" className="inline-flex items-center gap-2 transition-colors hover:text-primary">
            <Lock className="h-3.5 w-3.5" />
            Acesso administrativo
          </Link>
        </footer>
      </div>
    </main>
  );
}
