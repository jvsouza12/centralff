import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff, Loader2, LogIn, KeyRound, UserPlus, ShieldAlert, MailCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  requestPlayerPasswordReset,
  resendPlayerConfirmation,
  signInPlayer,
  signUpPlayer,
} from "@/lib/player-auth";

type Mode = "signin" | "signup" | "reset";

const MODES: ReadonlyArray<{ id: Mode; label: string }> = [
  { id: "signin", label: "Entrar" },
  { id: "signup", label: "Criar acesso" },
  { id: "reset", label: "Recuperar" },
];

function PasswordInput({
  id,
  label,
  value,
  onChange,
  autoComplete,
  hint,
  minLength,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  autoComplete: string;
  hint?: string;
  minLength?: number;
}) {
  const [show, setShow] = useState(false);
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="uppercase tracking-widest text-metal">
        {label}
      </Label>
      <div className="relative">
        <Input
          id={id}
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          maxLength={72}
          {...(minLength !== undefined ? { minLength } : {})}
          required
          className="h-12 bg-background/60 pr-12 font-mono"
        />
        <button
          type="button"
          onClick={() => setShow((s) => !s)}
          aria-label={show ? "Ocultar senha" : "Mostrar senha"}
          title={show ? "Ocultar senha" : "Mostrar senha"}
          className="absolute inset-y-0 right-0 flex w-12 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function PlayerAuthForm() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("signin");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [nick, setNick] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => setCooldown((value) => (value <= 1 ? 0 : value - 1)), 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  async function resendActivation() {
    if (resending || cooldown > 0) return;
    if (!email.trim()) {
      setError("Informe o e-mail do acesso para reenviar a ativação.");
      return;
    }
    setResending(true);
    setError("");
    try {
      const result = await resendPlayerConfirmation({ email });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setNotice(result.message ?? "Enviamos um novo e-mail de ativação.");
      setCooldown(60);
      toast.success("E-mail de ativação reenviado.");
    } catch {
      setError("Falha de conexão. Verifique sua internet e tente novamente.");
    } finally {
      setResending(false);
    }
  }

  function changeMode(next: string) {
    setMode(next as Mode);
    setError("");
    setNotice("");
    setPassword("");
    setConfirm("");
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (busy) return;
    setError("");
    setNotice("");
    if (mode === "signup" && password !== confirm) {
      setError("As senhas não coincidem.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "signin") {
        const result = await signInPlayer({ email, password });
        if (!result.ok) {
          setError(result.error);
          return;
        }
        setPassword("");
        toast.success("Acesso liberado.");
        await navigate({ to: "/arena", replace: true });
        return;
      }
      if (mode === "signup") {
        const result = await signUpPlayer({ nick, email, password });
        if (!result.ok) {
          setError(result.error);
          return;
        }
        setPassword("");
        setConfirm("");
        if (result.needsEmailConfirmation) {
          setMode("signin");
          setNotice("Acesso criado. Confirme o e-mail de ativação para entrar no portal.");
          return;
        }
        toast.success("Acesso criado. Bem-vindo ao portal.");
        await navigate({ to: "/arena", replace: true });
        return;
      }
      const result = await requestPlayerPasswordReset({ email });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setNotice(result.message ?? "Enviamos o link de redefinição para o seu e-mail.");
    } catch {
      setError("Falha de conexão. Verifique sua internet e tente novamente.");
    } finally {
      setBusy(false);
    }
  }

  const submitLabel: Record<Mode, string> = {
    signin: "ENTRAR NO PORTAL",
    signup: "CRIAR MEU ACESSO",
    reset: "ENVIAR LINK DE REDEFINIÇÃO",
  };
  const submitIcon: Record<Mode, React.ReactNode> = {
    signin: <LogIn className="h-5 w-5" />,
    signup: <UserPlus className="h-5 w-5" />,
    reset: <KeyRound className="h-5 w-5" />,
  };

  return (
    <div className="space-y-4">
      <div
        role="tablist"
        aria-label="Formas de acesso"
        className="grid grid-cols-3 gap-px border border-border bg-border"
      >
        {MODES.map((item) => (
          <button
            key={item.id}
            id={`auth-tab-${item.id}`}
            type="button"
            role="tab"
            aria-controls="auth-panel"
            aria-selected={mode === item.id}
            onClick={() => changeMode(item.id)}
            className={`h-11 font-display text-xs uppercase tracking-[0.14em] transition-colors sm:text-sm ${
              mode === item.id
                ? "bg-gradient-primary text-primary-foreground text-glow"
                : "bg-background/85 text-muted-foreground hover:bg-accent hover:text-foreground"
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      <form
        id="auth-panel"
        role="tabpanel"
        aria-labelledby={`auth-tab-${mode}`}
        onSubmit={submit}
        className="space-y-4"
        noValidate
      >
          {mode === "signup" && (
            <div className="space-y-2">
              <Label htmlFor="auth-nick" className="uppercase tracking-widest text-metal">
                Nick no CrossFire
              </Label>
              <Input
                id="auth-nick"
                value={nick}
                onChange={(e) => setNick(e.target.value)}
                autoComplete="nickname"
                maxLength={80}
                required
                className="h-12 bg-background/60 font-mono"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="auth-email" className="uppercase tracking-widest text-metal">
              {mode === "reset" ? "E-mail do acesso" : "E-mail"}
            </Label>
            <Input
              id="auth-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              inputMode="email"
              maxLength={160}
              required
              className="h-12 bg-background/60"
            />
          </div>

          {mode !== "reset" && (
            <PasswordInput
              id="auth-password"
              label="Senha"
              value={password}
              onChange={setPassword}
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
              {...(mode === "signup" ? { hint: "Mínimo de 8 caracteres.", minLength: 8 } : {})}
            />
          )}

          {mode === "signup" && (
            <PasswordInput
              id="auth-confirm"
              label="Repetir senha"
              value={confirm}
              onChange={setConfirm}
              autoComplete="new-password"
              minLength={8}
            />
          )}

          {notice && (
            <p role="status" aria-live="polite" className="flex items-start gap-2 border-l-2 border-success pl-3 text-sm text-success">
              <MailCheck className="mt-0.5 h-4 w-4 shrink-0" /> {notice}
            </p>
          )}
          {error && (
            <p role="alert" className="flex items-start gap-2 text-sm text-destructive">
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" /> {error}
            </p>
          )}

          <Button
            type="submit"
            variant={mode === "signin" ? "tactical" : "steel"}
            className="h-14 w-full gap-3"
            disabled={busy}
            aria-busy={busy}
          >
            {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : submitIcon[mode]}
            {busy ? "PROCESSANDO…" : submitLabel[mode]}
          </Button>
        </form>

      {mode === "signin" && (
        <p className="text-center text-xs text-muted-foreground">
          Não recebeu o e-mail de ativação?{" "}
          <button
            type="button"
            onClick={resendActivation}
            disabled={resending || cooldown > 0}
            aria-busy={resending}
            className="font-semibold text-primary underline-offset-4 hover:underline disabled:cursor-not-allowed disabled:text-muted-foreground disabled:no-underline"
          >
            {resending ? "Reenviando…" : cooldown > 0 ? `Reenviar em ${cooldown}s` : "Reenviar agora"}
          </button>
        </p>
      )}

      <p className="text-center text-xs text-muted-foreground">
        Acesso exclusivo de jogadores do clã. Não concede privilégios ADM.
      </p>
    </div>
  );
}
