// DESATIVADO — o login social intermediado foi removido junto com o Lovable
// Cloud Auth. O autenticador próprio (src/lib/player-auth.ts) não usa ícones de
// terceiros. Nenhum componente importa este arquivo.
export {};

