import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link, useNavigate } from "@tanstack/react-router";
import { LogOut, ShieldCheck, CheckCircle2, Loader2, KeyRound, Copy } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { DISCORD_INVITE } from "@/lib/operations";
import { Brand } from "@/components/Brand";
import { supabase } from "@/integrations/supabase/client";
import { getOwnRegistration, submitRegistration } from "@/lib/management.functions";
import { setNewPlayerPassword } from "@/lib/player-auth";
import { registrationSchema, groupRules, roomName } from "@/lib/operations";

export function PlayerRegistration() {
  const navigate = useNavigate();
  const cache = useQueryClient();
  const read = useServerFn(getOwnRegistration),
    submit = useServerFn(submitRegistration);
  const query = useQuery({
    queryKey: ["own-registration"],
    queryFn: () => read(),
    refetchInterval: 10000,
  });
  const [nick, setNick] = useState(""),
    [phone, setPhone] = useState(""),
    [auto, setAuto] = useState(""),
    [vip, setVip] = useState(""),
    [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [received, setReceived] = useState(false);
  const [showPassword, setShowPassword] = useState(false),
    [newPassword, setNewPassword] = useState(""),
    [confirmPassword, setConfirmPassword] = useState(""),
    [passwordBusy, setPasswordBusy] = useState(false),
    [passwordError, setPasswordError] = useState("");

  async function copyRoom() {
    try {
      await navigator.clipboard.writeText(roomName);
      toast.success("Nome da sala copiado.");
    } catch {
      toast.error("Não foi possível copiar. Selecione o texto manualmente.");
    }
  }

  async function changePassword(event: React.FormEvent) {
    event.preventDefault();
    if (passwordBusy) return;
    setPasswordError("");
    if (newPassword !== confirmPassword) {
      setPasswordError("As senhas não coincidem.");
      return;
    }
    setPasswordBusy(true);
    const result = await setNewPlayerPassword({ password: newPassword });
    setPasswordBusy(false);
    if (!result.ok) {
      setPasswordError(result.error);
      return;
    }
    setNewPassword("");
    setConfirmPassword("");
    setShowPassword(false);
    toast.success(result.message ?? "Senha atualizada.");
  }
  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError("");
    if (!auto || vip === "") {
      setError("Selecione a declaração Auto ON e a quantidade de armas VIP.");
      return;
    }
    try {
      const input = registrationSchema.parse({
        nick,
        phone,
        auto_on: auto === "yes",
        vip: Number(vip),
        consent,
      });
      setBusy(true);
      await submit({ data: input });
      setReceived(true);
      toast.success("Cadastro enviado! Aguarde a análise da administração.");
      setPhone("");
      await query.refetch();
    } catch (e) {
      setError(
        e instanceof Error && "issues" in e
          ? "Confira o nick (até 80 caracteres), celular, VIP de 0 a 100 e consentimento obrigatório."
          : e instanceof Error
            ? e.message
            : "Não foi possível enviar.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-background/95 px-5 py-3 backdrop-blur">
        <Link to="/" aria-label="Início" className="min-w-0">
          <Brand size="sm" />
        </Link>
        <div className="flex flex-wrap items-center justify-end gap-1">
          <Button variant="outline" size="sm" className="h-10" onClick={() => setShowPassword((value) => !value)} aria-expanded={showPassword}>
            <KeyRound />
            <span className="hidden sm:inline">Alterar senha</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-10"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              const result = await supabase.auth.signOut();
              if (result.error) {
                setError("Não foi possível sair.");
                setBusy(false);
                return;
              }
              cache.removeQueries({ queryKey: ["own-registration"] });
              await navigate({ to: "/", replace: true });
            }}
          >
            <LogOut />
            <span className="hidden sm:inline">Sair</span>
          </Button>
        </div>
      </header>
      <section className="mx-auto max-w-2xl px-5 py-10">
        <p className="clip-banner inline-flex border border-primary/45 bg-primary/10 px-3 py-1 font-display text-[11px] uppercase tracking-[0.32em] text-primary-glow">
          SenSaTIOnN
        </p>
        <h1 className="mt-5 font-display text-5xl uppercase tracking-[0.04em] text-foreground sm:text-6xl">
          Cadastro do <span className="text-primary">jogador</span>
        </h1>
        <p className="mt-3 text-metal">
          Organização do grupo no modo FF — Free Faca. Este cadastro não altera o
          CrossFire e não garante aprovação, presença ou horas no Controle diário.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-y border-border py-4">
          <div className="min-w-0">
            <p className="font-display text-[11px] uppercase tracking-[0.28em] text-primary">
              Sala oficial
            </p>
            <p className="break-all font-mono text-sm">{roomName}</p>
          </div>
          <Button variant="outline" onClick={copyRoom}>
            <Copy />
            Copiar nome da sala
          </Button>
          <Button asChild variant="outline"><a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">Entrar no Discord</a></Button>
        </div>
        {showPassword && (
          <form
            className="mt-6 space-y-4 border border-border bg-card p-5"
            onSubmit={changePassword}
            noValidate
          >
            <h3 className="font-display text-2xl">Alterar minha senha</h3>
            <p className="text-sm text-muted-foreground">
              Use pelo menos 8 caracteres. A troca não encerra este acesso.
            </p>
            <div>
              <Label htmlFor="player-new-password">Nova senha</Label>
              <Input
                id="player-new-password"
                className="mt-2 h-12 font-mono"
                type="password"
                autoComplete="new-password"
                minLength={8}
                maxLength={72}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="player-confirm-password">Repetir nova senha</Label>
              <Input
                id="player-confirm-password"
                className="mt-2 h-12 font-mono"
                type="password"
                autoComplete="new-password"
                minLength={8}
                maxLength={72}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
            {passwordError && (
              <p role="alert" className="text-sm text-destructive">
                {passwordError}
              </p>
            )}
            <div className="flex flex-wrap gap-2">
              <Button variant="tactical" type="submit" disabled={passwordBusy} aria-busy={passwordBusy}>
                {passwordBusy ? (
                  <>
                    <Loader2 className="animate-spin" /> Salvando…
                  </>
                ) : (
                  "Salvar nova senha"
                )}
              </Button>
              <Button
                variant="ghost"
                type="button"
                onClick={() => {
                  setShowPassword(false);
                  setNewPassword("");
                  setConfirmPassword("");
                  setPasswordError("");
                }}
              >
                Cancelar
              </Button>
            </div>
          </form>
        )}
        {query.isPending ? (
          <div className="space-y-3 py-8" aria-busy="true" aria-label="Carregando seu cadastro"><Skeleton className="h-6 w-1/2" /><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-3/4" /><Skeleton className="h-10 w-40" /></div>
        ) : query.isError ? (
          <div className="py-8">
            <p role="alert" className="text-destructive">
              Não foi possível consultar seu cadastro.
            </p>
            <Button className="mt-4" onClick={() => query.refetch()}>
              Tentar novamente
            </Button>
          </div>
        ) : query.data || received ? (
          <section className="mt-8 border-y border-border py-8" aria-live="polite">
            <CheckCircle2 className="mb-4 h-8 w-8 text-success" />
            <h3 className="font-display text-3xl">
              {query.data ? "Seu cadastro" : "Envio recebido"}
            </h3>
            {query.data ? (
              <>
                <p className="mt-3 break-all font-mono text-xl">{query.data.nick}</p>
                <p className="mt-2 text-primary">{query.data.status}</p>
                <p className="mt-3 text-sm text-muted-foreground">
                  Recebido em{" "}
                  {new Date(query.data.submitted_at).toLocaleString("pt-BR", {
                    timeZone: "America/Sao_Paulo",
                  })}
                </p>
              </>
            ) : (
              <p className="mt-3 text-metal">O envio foi recebido e aguarda análise ADM.</p>
            )}
            <p className="mt-4 text-sm text-muted-foreground">
              Correções ou exclusão: entre em contato com um administrador do grupo.
            </p>
          </section>
        ) : (
          <form className="mt-8 space-y-6" onSubmit={send}>
            <div>
              <Label htmlFor="player-nick">NickName CrossFire</Label>
              <Input
                id="player-nick"
                className="mt-2 h-12 font-mono"
                autoComplete="off"
                maxLength={80}
                value={nick}
                onChange={(e) => setNick(e.target.value)}
                required
              />
              <p className="mt-2 text-xs text-muted-foreground">
                Informe exatamente como no jogo, incluindo símbolos, maiúsculas e minúsculas.
              </p>
            </div>
            <div>
              <Label htmlFor="player-phone">Celular brasileiro com DDD</Label>
              <Input
                id="player-phone"
                className="mt-2 h-12"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                placeholder="(11) 9XXXX-XXXX"
                maxLength={30}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
              <p className="mt-2 text-xs text-muted-foreground">
                Visível exclusivamente para administradores autorizados.
              </p>
            </div>
            <fieldset>
              <legend className="text-sm font-medium">Declaração Auto ON</legend>
              <div className="mt-3 grid grid-cols-2 gap-3">
                {(
                  [
                    ["yes", "Sim, utilizo"],
                    ["no", "Não utilizo"],
                  ] as const
                ).map(([value, text]) => (
                  <label
                    key={value}
                    className="flex cursor-pointer items-center gap-3 border border-input p-4"
                  >
                    <input
                      type="radio"
                      name="auto-on"
                      required
                      value={value}
                      checked={auto === value}
                      onChange={() => setAuto(value)}
                    />
                    {text}
                  </label>
                ))}
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Autodeclaração: não verificamos o funcionamento de aplicativos externos. Consulte as
                regras oficiais do CrossFire sobre automação.
              </p>
            </fieldset>
            <div>
              <Label htmlFor="player-vip">Quantidade declarada de armas VIP</Label>
              <select
                className="field mt-2"
                id="player-vip"
                value={vip}
                required
                onChange={(e) => setVip(e.target.value)}
              >
                <option value="" disabled>
                  Selecione a quantidade
                </option>
                {Array.from({ length: 101 }, (_, i) => (
                  <option key={i} value={i}>
                    {i}
                  </option>
                ))}
              </select>
              <p className="mt-2 text-xs text-muted-foreground">
                Zero é válido. A quantidade é declarada, sem verificação externa.
              </p>
            </div>
            <section className="border-y border-border py-5">
              <h3 className="flex items-center gap-2 font-display text-2xl">
                <ShieldCheck className="h-5 w-5 text-primary" />
                Regras do grupo
              </h3>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-metal">
                {groupRules.map((rule) => (
                  <li key={rule}>{rule}</li>
                ))}
              </ul>
            </section>
            <p className="text-sm text-muted-foreground">
              Privacidade: seu telefone será usado exclusivamente para identificação administrativa.
              Dados visíveis apenas a administradores autorizados, sem publicação ou
              compartilhamento com outros jogadores. Provedores técnicos podem processar dados para
              hospedagem e armazenamento. Solicite correção ou exclusão ao ADM.
            </p>
            <label className="flex cursor-pointer items-start gap-3 text-sm">
              <input
                className="mt-1 h-4 w-4 shrink-0"
                type="checkbox"
                checked={consent}
                required
                onChange={(e) => setConsent(e.target.checked)}
              />
              <span>Confirmo que os dados são verdadeiros e aceito as regras do grupo.</span>
            </label>
            {error && (
              <p role="alert" className="text-sm text-destructive">
                {error}
              </p>
            )}
            <Button
              variant="tactical"
              className="h-12 w-full"
              type="submit"
              disabled={busy}
              aria-busy={busy}
            >
              {busy ? (
                <>
                  <Loader2 className="animate-spin" />
                  Enviando…
                </>
              ) : (
                "Enviar para análise ADM"
              )}
            </Button>
          </form>
        )}
        {error && (query.data || received) && (
          <p role="alert" className="mt-4 text-destructive">
            {error}
          </p>
        )}
      </section>
    </main>
  );
}
