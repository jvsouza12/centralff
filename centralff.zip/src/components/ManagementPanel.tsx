import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  Users,
  Timer,
  ListOrdered,
  Trophy,
  LogOut,
  Plus,
  Search,
  RefreshCw,
  Play,
  Square,
  Undo2,
  History,
  Copy,
  Trash2,
  ArrowUp,
  ArrowDown,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Brand } from "@/components/Brand";
import {
  getManagement,
  manage,
  getPrivateHistory,
  getRegistrationDetails,
  type ManagementOperation,
} from "@/lib/management.functions";
import { adminLogout } from "@/lib/admin.functions";
import { civilDay, clock, durationSeconds, roomName, groupRules, statuses, compareVIP } from "@/lib/operations";
import { Link, useNavigate } from "@tanstack/react-router";

type Data = Awaited<ReturnType<typeof getManagement>>;
type Registration = Data["registrations"][number];
type Details = Awaited<ReturnType<typeof getRegistrationDetails>>;
type Participant = Data["participants"][number];
const sections = [
  { id: "daily", label: "Controle diário", icon: Timer },
  { id: "players", label: "Jogadores", icon: Users },
  { id: "queue", label: "Fila de espera", icon: ListOrdered },
  { id: "ranking", label: "Ranking VIP", icon: Trophy },
] as const;
const time = (s: string) =>
  new Date(s).toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo" });

export function ManagementPanel({ login }: { login: string }) {
  const navigate = useNavigate(),
    cache = useQueryClient();
  const read = useServerFn(getManagement),
    operation = useServerFn(manage),
    logout = useServerFn(adminLogout),
    historyRead = useServerFn(getPrivateHistory),
    detailRead = useServerFn(getRegistrationDetails);
  const [section, setSection] = useState<string>("daily"),
    [day, setDay] = useState(civilDay()),
    [search, setSearch] = useState(""),
    [filter, setFilter] = useState(""),
    [page, setPage] = useState(1);
  const [busy, setBusy] = useState(false),
    [now, setNow] = useState(Date.now()),
    [nick, setNick] = useState("");
  const [editing, setEditing] = useState<Details | null>(null),
    [noting, setNoting] = useState<Participant | null>(null);
  const [note, setNote] = useState(""),
    [correction, setCorrection] = useState(0),
    [noteVersion, setNoteVersion] = useState(0);
  const [incident, setIncident] = useState<Registration | null>(null),
    [description, setDescription] = useState(""),
    [evidence, setEvidence] = useState(""),
    [incidentDate, setIncidentDate] = useState(civilDay()),
    [requestKey, setRequestKey] = useState("");
  const [historyTarget, setHistoryTarget] = useState<{
      participant_id?: string;
      registration_id?: string;
      nick: string;
    } | null>(null),
    [historyPage, setHistoryPage] = useState(1);
  const [confirmAction, setConfirmAction] = useState<{
    title: string;
    text: string;
    op: ManagementOperation;
  } | null>(null);
  const query = useQuery({
    queryKey: ["management", day, section === "players" ? search : "", filter, page],
    queryFn: () =>
      read({
        data: {
          day,
          search: section === "players" ? search : "",
          status: statuses.find((s) => s === filter),
          page,
        },
      }),
    refetchInterval: 5000,
  });
  const history = useQuery({
    queryKey: ["private-history", historyTarget, historyPage],
    queryFn: () =>
      historyRead({
        data: {
          participant_id: historyTarget?.participant_id,
          registration_id: historyTarget?.registration_id,
          page: historyPage,
        },
      }),
    enabled: Boolean(historyTarget),
    refetchInterval: 15000,
  });
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const data = query.data;
  async function act(op: ManagementOperation) {
    if (busy) return false;
    setBusy(true);
    try {
      await operation({ data: op });
      await cache.invalidateQueries({ queryKey: ["management"] });
      await cache.invalidateQueries({ queryKey: ["private-history"] });
      toast.success("Alteração salva.");
      return true;
    } catch (e) {
      const message = e instanceof Error ? e.message : "Não foi possível salvar.";
      toast.error(message);
      if (/conflito/i.test(message)) {
        setEditing(null);
        setNoting(null);
        toast.info("Registro alterado por outro ADM. Reabra a ficha para ver os dados atuais.");
      }
      await query.refetch();
      return false;
    } finally {
      setBusy(false);
    }
  }
  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copiado.");
    } catch {
      toast.error("Não foi possível copiar.");
    }
  }
  const participants =
    data?.participants.filter((p) =>
      p.nick.toLocaleLowerCase().includes(search.toLocaleLowerCase()),
    ) ?? [];
  const queue =
    data?.queue.filter((p) => p.nick.toLocaleLowerCase().includes(search.toLocaleLowerCase())) ??
    [];
  const activeCount = data?.sessions.filter((s) => !s.ended_at).length ?? 0;
  const markedCount = new Set(data?.sessions.map((s) => s.participant_id)).size;
  const completedCount = new Set(
    data?.sessions
      .filter(
        (s) =>
          s.ended_at &&
          !data.sessions.some((open) => open.participant_id === s.participant_id && !open.ended_at),
      )
      .map((s) => s.participant_id),
  ).size;
  const openHistory = (target: typeof historyTarget) => {
    setHistoryPage(1);
    setHistoryTarget(target);
  };
  return (
      <div className="min-h-screen bg-background md:grid md:grid-cols-[230px_minmax(0,1fr)]">
      <aside className="border-b border-border bg-sidebar md:border-b-0 md:border-r">
        <div className="clip-banner h-1 bg-hazard opacity-70" />
        <div className="block p-6 transition-opacity hover:opacity-90">
          <Link to="/" aria-label="Ir para o portal">
            <Brand size="sm" />
          </Link>
        </div>
        <div className="px-5 pb-4 font-display text-[11px] uppercase tracking-[0.28em] text-muted-foreground">
          Operação · SenSaTIOnN
        </div>
        <nav
          aria-label="Gestão administrativa"
          className="grid grid-cols-2 gap-1 p-3 md:grid-cols-1"
        >
          {sections.map(({ id, label, icon: Icon }) => (
            <Button
              key={id}
              variant={section === id ? "secondary" : "ghost"}
              className="h-12 justify-start whitespace-normal"
              onClick={() => {
                setSection(id);
                setSearch("");
                setPage(1);
                setFilter("");
              }}
            >
              <Icon />
              {label}
            </Button>
          ))}
        </nav>
        <div className="hidden p-5 text-xs text-muted-foreground md:block">
          <ShieldCheck className="mb-2 h-5 w-5 text-primary" />
          Área administrativa privada
        </div>
      </aside>
      <div className="min-w-0">
        <header className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-5 py-4">
          <span className="text-sm text-metal">
            ADM <span className="font-mono text-foreground">{login}</span>
          </span>
          <div className="flex items-center gap-2">
            <span
              role="status"
              className={`text-xs ${query.isError ? "text-destructive" : "text-success"}`}
            >
              {query.isError
                ? "Sem sincronização"
                : query.isFetching
                  ? "Sincronizando…"
                  : "Sincronizado"}
            </span>
            <Button
              variant="ghost"
              size="icon"
              title="Sincronizar"
              aria-label="Sincronizar"
              onClick={() => query.refetch()}
            >
              <RefreshCw />
            </Button>
            <Button
              variant="ghost"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  await logout();
                  await cache.cancelQueries({ queryKey: ["management"] });
                  await cache.cancelQueries({ queryKey: ["private-history"] });
                  cache.removeQueries({ queryKey: ["management"] });
                  cache.removeQueries({ queryKey: ["private-history"] });
                  setEditing(null);
                  setHistoryTarget(null);
                  await navigate({ to: "/adm", replace: true });
                } catch {
                  toast.error("Não foi possível sair.");
                  setBusy(false);
                }
              }}
            >
              <LogOut />
              Sair
            </Button>
          </div>
        </header>
        <main className="mx-auto max-w-6xl p-5 md:p-8">
          <p className="font-display text-[11px] uppercase tracking-[0.32em] text-primary">
            FF do 100
          </p>
          <h1 className="mt-2 font-display text-4xl uppercase tracking-[0.04em] text-foreground md:text-5xl">
            {sections.find((s) => s.id === section)?.label}
          </h1>
          {query.isError && (
            <p role="alert" className="my-4 text-destructive">
              Não foi possível atualizar. Os dados anteriores foram preservados.
            </p>
          )}
          {!data ? (
            <p className="py-12 text-muted-foreground">
              {query.isError ? "Tente sincronizar novamente." : "Carregando registros…"}
            </p>
          ) : (
            <>
              {section === "daily" && (
                <>
                  <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
                    {[
                      ["Participantes", data.participants.length],
                      ["Em autoclick", activeCount],
                      ["Com encerramento", completedCount],
                      ["Sem marcação", data.participants.length - markedCount],
                    ].map(([label, value]) => (
                      <div
                        key={label}
                        className="clip-tactical border border-border border-l-2 border-l-primary bg-secondary/50 p-4"
                      >
                        <p className="font-display text-[11px] uppercase tracking-[0.24em] text-muted-foreground">
                          {label}
                        </p>
                        <p className="mt-1 font-mono text-3xl text-foreground">{value}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 h-1 bg-secondary">
                    <div
                      className="h-1 bg-success"
                      style={{
                        width: `${data.participants.length ? (markedCount / data.participants.length) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </>
              )}
              {section !== "ranking" && (
                <div className="mt-6 flex flex-wrap items-end gap-3">
                  <div className="relative min-w-0 flex-1">
                    <Label htmlFor="nick-search">Buscar nick</Label>
                    <Search className="absolute bottom-3 left-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="nick-search"
                      className="mt-2 h-11 pl-9"
                      value={search}
                      maxLength={80}
                      onChange={(e) => {
                        setSearch(e.target.value);
                        setPage(1);
                      }}
                    />
                  </div>
                  {section === "daily" && (
                    <div>
                      <Label htmlFor="daily-date">Data · São Paulo</Label>
                      <Input
                        className="mt-2 h-11 w-44"
                        id="daily-date"
                        type="date"
                        value={day}
                        max={data.today}
                        onChange={(e) => {
                          if (
                            e.target.value &&
                            (!data.active.length ||
                              window.confirm(
                                "Há sessões abertas. Trocar a data sem encerrar essas sessões?",
                              ))
                          )
                            setDay(e.target.value);
                        }}
                      />
                    </div>
                  )}
                  {section === "players" && (
                    <div>
                      <Label htmlFor="status-filter">Status</Label>
                      <select
                        className="field mt-2"
                        id="status-filter"
                        value={filter}
                        onChange={(e) => {
                          setFilter(e.target.value);
                          setPage(1);
                        }}
                      >
                        <option value="">Todos</option>
                        {statuses.map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}
              {(section === "queue" || section === "daily") && (
                <form
                  className="my-5 flex flex-wrap gap-2"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (
                      await act({
                        command: section === "queue" ? "queue_add" : "participant_add",
                        nick,
                      })
                    )
                      setNick("");
                  }}
                >
                  <Input
                    className="h-11 min-w-0 flex-1"
                    aria-label={
                      section === "queue" ? "Nick para a fila" : "Nick para o controle diário"
                    }
                    placeholder="NickName exato"
                    value={nick}
                    onChange={(e) => setNick(e.target.value)}
                    required
                    maxLength={80}
                  />
                  <Button className="h-11" disabled={busy} type="submit">
                    <Plus />
                    {section === "queue" ? "Adicionar à fila" : "Adicionar participante"}
                  </Button>
                </form>
              )}
              {section === "daily" && (
                <>
                  <p className="mb-4 text-sm text-muted-foreground">
                    Registros de {day.split("-").reverse().join("/")} · {markedCount} de{" "}
                    {data.participants.length} participantes com marcação
                  </p>
                  <div className="divide-y divide-border border-y border-border">
                    {participants.map((p, index) => {
                      const sessions = data.sessions.filter((s) => s.participant_id === p.id),
                        open = data.active.find((s) => s.participant_id === p.id),
                        last = sessions.at(-1),
                        entry = data.notes.find((n) => n.participant_id === p.id);
                      const total =
                        sessions.reduce(
                          (sum, s) => sum + durationSeconds(s.started_at, s.ended_at, now),
                          0,
                        ) + (entry?.correction_seconds ?? 0);
                      return (
                        <article key={p.id} className="flex flex-wrap items-center gap-4 py-5">
                          <span className="w-6 font-mono text-xs text-muted-foreground">
                            {String(index + 1).padStart(2, "0")}
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="break-all font-mono">{p.nick}</p>
                            <p
                              className={`mt-1 text-xs ${open ? "text-success" : "text-muted-foreground"}`}
                            >
                              {open
                                ? `● Em autoclick · início ${time(open.started_at)}${open.day !== day ? ` · ${open.day}` : ""}`
                                : sessions.length
                                  ? "■ Fora de autoclick"
                                  : "Sem marcação nesta data"}
                            </p>
                            {open && open.day !== day && (
                              <p className="mt-1 text-xs text-warning">
                                Sessão de {open.day}:{" "}
                                {clock(durationSeconds(open.started_at, null, now))} · não integra o
                                total de {day}
                              </p>
                            )}
                            {entry?.note && (
                              <p className="mt-1 break-words text-sm text-metal">{entry.note}</p>
                            )}
                            {Boolean(entry?.correction_seconds) && (
                              <p className="text-xs text-warning">
                                Correção ADM: +{clock(entry?.correction_seconds ?? 0)}
                              </p>
                            )}
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Total de {day}</p>
                            <span className="font-mono text-xl tabular-nums">
                              {sessions.length || entry ? clock(total) : "—"}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {open ? (
                              <Button
                                variant="outline"
                                disabled={busy}
                                onClick={() =>
                                  act({
                                    command: "session_stop",
                                    id: open.id,
                                    version: open.version,
                                  })
                                }
                              >
                                <Square />
                                Encerrar
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                disabled={busy || day !== data.today}
                                onClick={() =>
                                  act({ command: "session_start", participant_id: p.id, day })
                                }
                              >
                                <Play />
                                Iniciar
                              </Button>
                            )}
                            {last?.ended_at &&
                              now - new Date(last.ended_at).getTime() <= 30000 &&
                              !open && (
                                <Button
                                  variant="ghost"
                                  aria-label={`Desfazer saída de ${p.nick}`}
                                  title="Desfazer saída (30 segundos)"
                                  disabled={busy}
                                  onClick={() =>
                                    act({
                                      command: "session_undo",
                                      id: last.id,
                                      version: last.version,
                                    })
                                  }
                                >
                                  <Undo2 />
                                </Button>
                              )}
                            <Button
                              variant="ghost"
                              size="icon"
                              title="Histórico"
                              aria-label={`Histórico de ${p.nick}`}
                              onClick={() => openHistory({ participant_id: p.id, nick: p.nick })}
                            >
                              <History />
                            </Button>
                            <Button
                              variant="ghost"
                              onClick={() => {
                                setNoting(p);
                                setNote(entry?.note ?? "");
                                setCorrection((entry?.correction_seconds ?? 0) / 60);
                                setNoteVersion(entry?.version ?? 0);
                              }}
                            >
                              Observação
                            </Button>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                  {!participants.length && (
                    <Empty
                      text={
                        search
                          ? "Nenhum nick encontrado."
                          : "Nenhum participante no Controle diário."
                      }
                    />
                  )}
                </>
              )}
              {section === "queue" && (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-3 border-y border-border py-4">
                    <div>
                      <p className="text-xs text-primary">SALA</p>
                      <p className="break-words font-mono text-sm">{roomName}</p>
                      <p className="mt-2 text-sm text-muted-foreground">
                        {data.queue.length} na fila
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      disabled={!data.queue.length}
                      onClick={() => copy(data.queue.map((p) => p.nick).join("\n"))}
                    >
                      <Copy />
                      Copiar fila
                    </Button>
                  </div>
                  <div className="border-b border-border py-4">
                    <p className="text-xs text-primary">REGRAS DO GRUPO</p>
                    <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-metal">
                      {groupRules.map((rule) => (
                        <li key={rule}>{rule}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="divide-y divide-border">
                    {queue.map((q) => (
                      <article key={q.id} className="flex flex-wrap items-center gap-3 py-4">
                        <span className="w-8 font-mono text-primary">
                          {String(data.queue.findIndex((i) => i.id === q.id) + 1).padStart(2, "0")}
                        </span>
                        <span className="min-w-0 flex-1 break-all font-mono">{q.nick}</span>
                        <div className="flex gap-1">
                          {(["up", "down"] as const).map((direction) => (
                            <Button
                              key={direction}
                              size="icon"
                              variant="ghost"
                              title={direction === "up" ? "Subir" : "Descer"}
                              aria-label={`${direction === "up" ? "Subir" : "Descer"} ${q.nick}`}
                              disabled={
                                busy ||
                                (direction === "up"
                                  ? data.queue[0]?.id === q.id
                                  : data.queue.at(-1)?.id === q.id)
                              }
                              onClick={() =>
                                act({
                                  command: "queue_move",
                                  id: q.id,
                                  version: q.version,
                                  direction,
                                })
                              }
                            >
                              {direction === "up" ? <ArrowUp /> : <ArrowDown />}
                            </Button>
                          ))}
                          <Button
                            size="icon"
                            variant="ghost"
                            title="Copiar nick"
                            aria-label={`Copiar ${q.nick}`}
                            onClick={() => copy(q.nick)}
                          >
                            <Copy />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            title="Remover da fila"
                            aria-label={`Remover ${q.nick}`}
                            onClick={() =>
                              setConfirmAction({
                                title: "Remover da fila?",
                                text: `${q.nick} será removido somente da fila de espera.`,
                                op: { command: "queue_remove", id: q.id, version: q.version },
                              })
                            }
                          >
                            <Trash2 className="text-destructive" />
                          </Button>
                        </div>
                      </article>
                    ))}
                  </div>
                  {!queue.length && (
                    <Empty text={search ? "Nenhum nick encontrado." : "A fila está vazia."} />
                  )}
                </>
              )}
              {section === "players" && (
                <>
                  <div className="mt-5 divide-y divide-border border-y border-border">
                    {data.registrations.map((r) => (
                      <article key={r.id} className="py-5">
                        <div className="flex flex-wrap items-center gap-3">
                          <div className="min-w-0 flex-1">
                            <p className="break-all font-mono">{r.nick}</p>
                            <p className="mt-1 text-sm text-muted-foreground">
                              Enviado em{" "}
                              {new Date(r.submitted_at).toLocaleString("pt-BR", {
                                timeZone: "America/Sao_Paulo",
                              })}
                            </p>
                          </div>
                          <span
                            className={
                              r.status === "Ativo"
                                ? "text-success"
                                : r.status === "Banido" || r.status === "Suspenso"
                                  ? "text-destructive"
                                  : "text-warning"
                            }
                          >
                            {r.status}
                          </span>
                          <Button
                            variant="outline"
                            disabled={busy}
                            onClick={async () => {
                              setBusy(true);
                              try {
                                setEditing(await detailRead({ data: { id: r.id } }));
                              } catch {
                                toast.error("Não foi possível abrir a ficha. Sincronize a lista.");
                              } finally {
                                setBusy(false);
                              }
                            }}
                          >
                            Abrir ficha
                          </Button>
                        </div>
                        <p className="mt-2 text-sm text-metal">
                          Auto ON: {r.auto_on ? "Sim, utilizo" : "Não utilizo"} · VIP declarado:{" "}
                          {r.vip}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-1">
                          <Button
                            variant="ghost"
                            onClick={() => {
                              setIncident(r);
                              setDescription("");
                              setEvidence("");
                              setRequestKey(crypto.randomUUID());
                              setIncidentDate(civilDay());
                            }}
                          >
                            Registrar ocorrência
                          </Button>
                          <Button
                            variant="ghost"
                            onClick={() => openHistory({ registration_id: r.id, nick: r.nick })}
                          >
                            <History />
                            Conduta
                          </Button>
                          <Button
                            variant="ghost"
                            aria-label={`Excluir cadastro de ${r.nick}`}
                            onClick={() =>
                              setConfirmAction({
                                title: "Excluir cadastro?",
                                text: `${r.nick}: telefone, consentimento e ocorrências serão excluídos. O participante e as sessões do Controle diário serão preservados.`,
                                op: {
                                  command: "registration_delete",
                                  id: r.id,
                                  version: r.version,
                                },
                              })
                            }
                          >
                            <Trash2 className="text-destructive" />
                          </Button>
                        </div>
                      </article>
                    ))}
                  </div>
                  {!data.registrations.length && <Empty text="Nenhum cadastro encontrado." />}
                  <div className="mt-5 flex items-center justify-between">
                    <p className="text-sm text-muted-foreground">
                      {data.count} cadastros · Página {page}
                    </p>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        aria-label="Página anterior"
                        disabled={page <= 1}
                        onClick={() => setPage((p) => p - 1)}
                      >
                        <ChevronLeft />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        aria-label="Próxima página"
                        disabled={page * 20 >= data.count}
                        onClick={() => setPage((p) => p + 1)}
                      >
                        <ChevronRight />
                      </Button>
                    </div>
                  </div>
                </>
              )}
              {section === "ranking" && (
                <>
                  <p className="mt-3 text-sm text-muted-foreground">
                    Quantidade declarada · jogadores com zero não aparecem na classificação.
                  </p>
                  <div className="mt-6 divide-y divide-border border-y border-border">
                    {[...data.ranking].sort(compareVIP).map((r, index) => (
                      <article key={r.id} className="flex items-center gap-5 py-5">
                        <span className="w-8 font-mono text-xl text-primary">
                          {String(index + 1).padStart(2, "0")}
                        </span>
                        <span className="min-w-0 flex-1 break-all font-mono">{r.nick}</span>
                        <span className="font-mono text-2xl">
                          {r.vip}
                          <span className="ml-2 text-xs text-muted-foreground">VIP</span>
                        </span>
                      </article>
                    ))}
                  </div>
                  {!data.ranking.length && (
                    <Empty text="Nenhuma declaração VIP para classificar." />
                  )}
                </>
              )}
            </>
          )}
        </main>
      </div>
      <Dialog
        open={Boolean(editing)}
        onOpenChange={(v) => {
          if (!v) setEditing(null);
        }}
      >
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Ficha do jogador</DialogTitle>
            <DialogDescription className="break-all">
              {editing?.nick} · dados privados
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <form
              className="space-y-4"
              onSubmit={async (e) => {
                e.preventDefault();
                if (
                  await act({
                    command: "registration_update",
                    id: editing.id,
                    version: editing.version,
                    phone: editing.phone,
                    auto_on: editing.auto_on,
                    vip: editing.vip,
                    status: editing.status as (typeof statuses)[number],
                  })
                )
                  setEditing(null);
              }}
            >
              <div>
                <Label htmlFor="edit-phone">Celular com DDD</Label>
                <Input
                  id="edit-phone"
                  value={editing.phone}
                  inputMode="tel"
                  maxLength={30}
                  onChange={(e) => setEditing({ ...editing, phone: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit-auto">Declaração Auto ON</Label>
                <select
                  id="edit-auto"
                  className="field"
                  value={String(editing.auto_on)}
                  onChange={(e) => setEditing({ ...editing, auto_on: e.target.value === "true" })}
                >
                  <option value="true">Sim, utilizo</option>
                  <option value="false">Não utilizo</option>
                </select>
              </div>
              <div>
                <Label htmlFor="edit-vip">Armas VIP declaradas</Label>
                <Input
                  id="edit-vip"
                  type="number"
                  min={0}
                  max={100}
                  step={1}
                  value={editing.vip}
                  onChange={(e) => setEditing({ ...editing, vip: Number(e.target.value) })}
                />
              </div>
              <div>
                <Label htmlFor="edit-status">Status</Label>
                <select
                  className="field"
                  id="edit-status"
                  value={editing.status}
                  onChange={(e) => setEditing({ ...editing, status: e.target.value })}
                >
                  {statuses.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              <p className="text-sm text-muted-foreground">
                Consentimento: {editing.consent ? "Aceito" : "Não aceito"} em{" "}
                {new Date(editing.consent_at).toLocaleString("pt-BR", {
                  timeZone: "America/Sao_Paulo",
                })}
              </p>
              <Button className="w-full" disabled={busy} type="submit">
                Salvar ficha
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
      <Dialog
        open={Boolean(noting)}
        onOpenChange={(v) => {
          if (!v) setNoting(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Observação e correção ADM</DialogTitle>
            <DialogDescription>
              {noting?.nick} · {day}
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={async (e) => {
              e.preventDefault();
              if (
                noting &&
                (await act({
                  command: "daily_note",
                  participant_id: noting.id,
                  day,
                  note,
                  correction_seconds: Math.round(correction * 60),
                  version: noteVersion,
                }))
              )
                setNoting(null);
            }}
          >
            <Label htmlFor="daily-note">Observação privada</Label>
            <textarea
              className="field min-h-24"
              id="daily-note"
              value={note}
              maxLength={2000}
              onChange={(e) => setNote(e.target.value)}
            />
            <Label htmlFor="correction">Tempo adicional por correção ADM (minutos)</Label>
            <Input
              id="correction"
              type="number"
              min={0}
              max={1440}
              step={1}
              value={correction}
              onChange={(e) => setCorrection(Number(e.target.value))}
            />
            <p className="text-xs text-muted-foreground">
              Adicional identificado como correção; não modifica os intervalos reais.
            </p>
            <Button type="submit" disabled={busy}>
              Salvar registro de {day}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={Boolean(incident)}
        onOpenChange={(v) => {
          if (!v) setIncident(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Registrar ocorrência privada</DialogTitle>
            <DialogDescription>{incident?.nick}</DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={async (e) => {
              e.preventDefault();
              if (
                incident &&
                (await act({
                  command: "incident_add",
                  registration_id: incident.id,
                  happened_on: incidentDate,
                  description,
                  evidence,
                  request_key: requestKey,
                }))
              )
                setIncident(null);
            }}
          >
            <Label htmlFor="incident-day">Data da ocorrência</Label>
            <Input
              type="date"
              id="incident-day"
              max={civilDay()}
              value={incidentDate}
              onChange={(e) => setIncidentDate(e.target.value)}
              required
            />
            <Label htmlFor="incident-description">Descrição</Label>
            <textarea
              id="incident-description"
              className="field min-h-24"
              required
              maxLength={2000}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <Label htmlFor="incident-evidence">Evidência (texto ou URL)</Label>
            <textarea
              id="incident-evidence"
              className="field"
              maxLength={2000}
              value={evidence}
              onChange={(e) => setEvidence(e.target.value)}
            />
            <Button disabled={busy} type="submit">
              Salvar ocorrência
            </Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={Boolean(historyTarget)}
        onOpenChange={(v) => {
          if (!v) setHistoryTarget(null);
        }}
      >
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Histórico privado</DialogTitle>
            <DialogDescription className="break-all">{historyTarget?.nick}</DialogDescription>
          </DialogHeader>
          {history.isError ? (
            <p role="alert">Não foi possível carregar o histórico.</p>
          ) : !history.data ? (
            <p>Carregando…</p>
          ) : (
            <>
              <div className="divide-y divide-border">
                {history.data.sessions.map((s) => (
                  <div key={s.id} className="py-3">
                    <p className="font-mono">
                      {s.day} · {s.ended_at ? "Encerrada" : "Em autoclick"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {time(s.started_at)} → {s.ended_at ? time(s.ended_at) : "Em andamento"} ·{" "}
                      {clock(durationSeconds(s.started_at, s.ended_at, now))}
                    </p>
                  </div>
                ))}
                {history.data.notes.map((n) => (
                  <div key={n.day} className="py-3">
                    <p className="font-mono">
                      {n.day} · Correção ADM +{clock(n.correction_seconds)}
                    </p>
                    <p className="break-words text-sm text-metal">{n.note || "Sem observação"}</p>
                  </div>
                ))}
                {history.data.incidents.map((i) => (
                  <div key={i.id} className="py-3">
                    <p className="font-mono">{i.happened_on}</p>
                    <p className="break-words">{i.description}</p>
                    <p className="mt-1 break-all text-sm text-muted-foreground">{i.evidence}</p>
                  </div>
                ))}
              </div>
              {!history.data.count && !history.data.notes.length && (
                <p className="text-muted-foreground">Não há registros neste histórico.</p>
              )}
              <div className="flex justify-between">
                <Button
                  variant="outline"
                  disabled={historyPage <= 1}
                  onClick={() => setHistoryPage((p) => p - 1)}
                >
                  Anterior
                </Button>
                <span>Página {historyPage}</span>
                <Button
                  variant="outline"
                  disabled={historyPage * 20 >= history.data.count}
                  onClick={() => setHistoryPage((p) => p + 1)}
                >
                  Próxima
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      <Dialog
        open={Boolean(confirmAction)}
        onOpenChange={(v) => {
          if (!v) setConfirmAction(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{confirmAction?.title}</DialogTitle>
            <DialogDescription>{confirmAction?.text}</DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setConfirmAction(null)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              disabled={busy}
              onClick={async () => {
                if (confirmAction && (await act(confirmAction.op))) setConfirmAction(null);
              }}
            >
              Confirmar remoção
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
function Empty({ text }: { text: string }) {
  return (
    <div className="py-16 text-center">
      <ListOrdered className="mx-auto mb-4 h-8 w-8 text-muted-foreground" />
      <p className="text-muted-foreground">{text}</p>
    </div>
  );
}
