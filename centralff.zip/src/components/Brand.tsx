import { cn } from "@/lib/utils";

/**
 * Emblema da marca: escudo tático com lâminas cruzadas (FF — Free Faca)
 * sobre uma mira. Vetorial, sem imagem externa.
 */
export function BrandMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      role="img"
      aria-label="Emblema do clã"
      className={cn("shrink-0 text-primary", className)}
    >
      <path
        d="M24 2.5 43 10.5v13.2c0 10.6-7.9 18.6-19 21.8-11.1-3.2-19-11.2-19-21.8V10.5L24 2.5Z"
        fill="#1b2030"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <circle cx="24" cy="24" r="6.5" fill="none" stroke="currentColor" strokeWidth="1.2" opacity="0.75" />
      <g stroke="currentColor" strokeWidth="1.2" opacity="0.75">
        <path d="M24 15.5v3M24 29.5v3M15.5 24h3M29.5 24h3" />
      </g>
      <g fill="var(--foreground)">
        <g transform="rotate(45 24 24)">
          <path d="M22 8.5 24 6l2 2.5V26h-4V8.5Z" />
          <path d="M19.5 26.5h9v2.6h-9z" />
          <path d="M22 29.1h4v10.4l-2 1.6-2-1.6V29.1Z" />
        </g>
        <g transform="rotate(-45 24 24)">
          <path d="M22 8.5 24 6l2 2.5V26h-4V8.5Z" />
          <path d="M19.5 26.5h9v2.6h-9z" />
          <path d="M22 29.1h4v10.4l-2 1.6-2-1.6V29.1Z" />
        </g>
      </g>
    </svg>
  );
}

/** Assinatura compacta da marca: emblema + nome do clã. */
export function Brand({
  size = "lg",
  className,
}: {
  size?: "lg" | "sm";
  className?: string;
}) {
  const big = size === "lg";
  return (
    <div className={cn("flex select-none items-center gap-3", className)}>
      <BrandMark className={big ? "h-12 w-12" : "h-9 w-9"} />
      <div className="min-w-0 leading-none">
        <p
          className={cn(
            "font-display font-bold uppercase tracking-[0.16em] text-foreground",
            big ? "text-3xl" : "text-xl",
          )}
        >
          SenSa<span className="text-primary">TIOnN</span>
        </p>
        <p
          className={cn(
            "font-display uppercase tracking-[0.28em] text-metal",
            big ? "mt-1 text-xs" : "mt-0.5 text-[10px]",
          )}
        >
          FF do 100
        </p>
      </div>
    </div>
  );
}
