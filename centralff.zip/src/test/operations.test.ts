import { describe, expect, it } from 'vitest'
import { civilDay, clock, compareVIP, dateSchema, durationSeconds, nickSchema, normalizePhone, registrationSchema } from '@/lib/operations'

const registration = { nick: 'N!cK_Ç', phone: '(11) 98765-4321', auto_on: false, vip: 0, consent: true }
describe('Registration rules', () => {
  it('preserves exact nickname symbols and case up to 80 characters', () => {
    expect(registrationSchema.parse(registration).nick).toBe('N!cK_Ç')
    expect(nickSchema.safeParse('a'.repeat(80)).success).toBe(true)
    expect(nickSchema.safeParse('a'.repeat(81)).success).toBe(false)
    expect(nickSchema.safeParse('  ').success).toBe(false)
  })
  it('accepts zero through 100 VIP but not fractions or out-of-range values', () => {
    for (const vip of [0, 100]) expect(registrationSchema.parse({ ...registration, vip }).vip).toBe(vip)
    for (const vip of [-1, 101, 1.5]) expect(registrationSchema.safeParse({ ...registration, vip }).success).toBe(false)
  })
  it('requires explicit consent', () => {
    expect(registrationSchema.safeParse({ ...registration, consent: false }).success).toBe(false)
  })
  it('requires an explicit Auto ON boolean, accepts false', () => {
    expect(registrationSchema.parse(registration).auto_on).toBe(false)
    expect(registrationSchema.safeParse({ ...registration, auto_on: undefined }).success).toBe(false)
  })
  it('normalizes Brazilian mobile numbers and rejects invalid DDD', () => {
    expect(normalizePhone('(11) 98765-4321')).toBe('5511987654321')
    expect(() => normalizePhone('(20) 98765-4321')).toThrow()
    expect(() => normalizePhone('(11) 8765-4321')).toThrow()
  })
})
describe('Daily control and ranking', () => {
  it('uses Sao Paulo civil date at UTC midnight', () => {
    expect(civilDay(new Date('2026-10-16T01:30:00Z'))).toBe('2026-10-15')
    expect(civilDay(new Date('2026-10-16T03:00:00Z'))).toBe('2026-10-16')
  })
  it('sums real intervals without counting gaps', () => {
    const first = durationSeconds('2026-10-15T10:00:00Z', '2026-10-15T10:30:00Z', 0)
    const second = durationSeconds('2026-10-15T11:00:00Z', '2026-10-15T11:15:00Z', 0)
    expect(first + second).toBe(2700)
    expect(clock(first + second)).toBe('00:45:00')
  })
  it('computes running duration from persisted start', () => {
    expect(durationSeconds('2026-10-15T10:00:00Z', null, Date.parse('2026-10-15T10:01:05Z'))).toBe(65)
  })
  it('sorts VIP descending and nick alphabetically for ties', () => {
    const rows = [{ nick: 'Zeta', vip: 5 }, { nick: 'Beta', vip: 9 }, { nick: 'Alpha', vip: 9 }]
    expect(rows.sort(compareVIP).map(r => r.nick)).toEqual(['Alpha', 'Beta', 'Zeta'])
  })
  it('rejects invalid civil dates', () => {
    expect(dateSchema.safeParse('2026-02-30').success).toBe(false)
    expect(dateSchema.safeParse('2026-02-28').success).toBe(true)
  })
})