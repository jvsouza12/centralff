import { describe, expect, it } from "vitest";

import { authErrorMessage, resetSchema, signInSchema, signUpSchema } from "@/lib/player-auth";

describe("autenticador próprio do projeto", () => {
  it("exige e-mail válido e senha no login", () => {
    expect(signInSchema.safeParse({ email: "nao-eh-email", password: "12345678" }).success).toBe(false);
    expect(signInSchema.safeParse({ email: "jogador@clan.com", password: "" }).success).toBe(false);
    expect(signInSchema.safeParse({ email: "jogador@clan.com", password: "senha-forte" }).success).toBe(true);
  });

  it("exige nick e senha de no mínimo 8 caracteres no cadastro", () => {
    const base = { nick: "SenSaTIOnN", email: "jogador@clan.com" };
    expect(signUpSchema.safeParse({ ...base, password: "curta" }).success).toBe(false);
    expect(signUpSchema.safeParse({ ...base, password: "senha-forte" }).success).toBe(true);
  });

  it("normaliza espaços em volta do e-mail", () => {
    const parsed = resetSchema.safeParse({ email: "  jogador@clan.com  " });
    expect(parsed.success && parsed.data.email).toBe("jogador@clan.com");
  });

  it("traduz falhas do provedor sem vazar detalhes internos", () => {
    expect(authErrorMessage("Invalid login credentials")).toBe("E-mail ou senha incorretos.");
    expect(authErrorMessage("Email not confirmed")).toBe("Confirme o e-mail de ativação antes de entrar.");
    expect(authErrorMessage(new Error("erro desconhecido"))).toBe(
      "Não foi possível concluir agora. Tente novamente.",
    );
  });
});
