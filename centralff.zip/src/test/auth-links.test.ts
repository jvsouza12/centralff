import { describe, expect, it } from "vitest";

import {
  authErrorMessage,
  clearRecoveryIntent,
  hasAuthLinkParams,
  hasRecoveryIntent,
  markRecoveryIntent,
  readAuthLinkFeedback,
  resendConfirmationSchema,
} from "@/lib/player-auth";

describe("links de e-mail do autenticador próprio", () => {
  it("reconhece link de recuperação de senha", () => {
    const feedback = readAuthLinkFeedback("https://portal.clan/#type=recovery&access_token=abc");
    expect(feedback?.kind).toBe("recovery");
  });

  it("reconhece confirmação de cadastro", () => {
    const feedback = readAuthLinkFeedback(
      "https://portal.clan/?type=signup&access_token=abc&refresh_token=def",
    );
    expect(feedback?.kind).toBe("confirmed");
  });

  it("explica links expirados sem revelar detalhes internos", () => {
    const feedback = readAuthLinkFeedback(
      "https://portal.clan/#error_code=otp_expired&error_description=Email+link+is+invalid+or+has+expired",
    );
    expect(feedback).toEqual({
      kind: "error",
      message: "Este link expirou ou já foi usado. Solicite um novo e-mail.",
    });
  });

  it("ignora URLs sem parâmetros de autenticação", () => {
    expect(readAuthLinkFeedback("https://portal.clan/arena")).toBeNull();
    expect(readAuthLinkFeedback("")).toBeNull();
  });

  it("valida o e-mail do reenvio de ativação", () => {
    expect(resendConfirmationSchema.safeParse({ email: "x" }).success).toBe(false);
    expect(resendConfirmationSchema.safeParse({ email: " jogador@clan.com " }).success).toBe(true);
  });

  it("detecta links de e-mail sem confundir URLs normais", () => {
    expect(hasAuthLinkParams("https://portal.clan/#type=recovery&access_token=abc")).toBe(true);
    expect(hasAuthLinkParams("https://portal.clan/?code=abc123")).toBe(true);
    expect(hasAuthLinkParams("https://portal.clan/arena?pagina=2")).toBe(false);
    expect(hasAuthLinkParams("https://portal.clan/")).toBe(false);
  });

  it("valida o estado de intenção de recuperação", () => {
    clearRecoveryIntent();
    expect(hasRecoveryIntent()).toBe(false);
    markRecoveryIntent();
    expect(hasRecoveryIntent()).toBe(true);
    // Expirado: não deve valer após a janela máxima.
    expect(hasRecoveryIntent(-1)).toBe(false);
    expect(hasRecoveryIntent()).toBe(false);
  });

  it("traduz novas falhas do provedor para português", () => {
    expect(authErrorMessage("User already confirmed")).toBe(
      "Este acesso já está ativo. Use a aba Entrar.",
    );
    expect(authErrorMessage("User not found")).toBe("Não encontramos um acesso com este e-mail.");
  });
});
