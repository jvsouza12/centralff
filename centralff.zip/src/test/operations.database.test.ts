// Database checks use a single rolled-back transaction. No fixture survives the test.
import postgres from "postgres";
import { expect, it } from "vitest";

const connection = process.env["SUPABASE_DB_URL"];
it.skipIf(!connection)(
  "enforces session, queue, approval and private-data rules transactionally",
  async (context) => {
    if (!connection) return;
    const db = postgres(connection, { max: 1, prepare: false });
    const rolledBack = new Error("Transaction test rollback");
    try {
      const [access] =
        await db`select pg_has_role(current_user, 'service_role', 'MEMBER') as allowed`;
      if (!access?.["allowed"]) {
        context.skip();
        return;
      }
      await db.begin(async (tx) => {
        await tx`set local role service_role`;
        const op = async (command: string, payload: Record<string, string | number | boolean>) =>
          tx`select public.ff_admin_operation(${command}, ${tx.json(payload)})`;
        const suffix = crypto.randomUUID();
        const nick = `Transaction-${suffix}`;
        await op("participant_add", { nick });
        const [participant] = await tx`select id from public.ff_participants where nick=${nick}`;
        if (!participant) throw new Error("Missing transaction participant");
        const [date] = await tx`select (now() at time zone 'America/Sao_Paulo')::date::text as day`;
        if (!date) throw new Error("Missing civil date");
        await op("session_start", { participant_id: participant["id"], day: date["day"] });
        await op("session_start", { participant_id: participant["id"], day: date["day"] });
        const sessions =
          await tx`select * from public.ff_daily_sessions where participant_id=${participant["id"]}`;
        expect(sessions).toHaveLength(1);
        const session = sessions[0];
        if (!session) throw new Error("Missing session");
        await op("session_stop", { id: session["id"], version: 1 });
        await op("session_stop", { id: session["id"], version: 1 });
        const [stopped] =
          await tx`select version,ended_at from public.ff_daily_sessions where id=${session["id"]}`;
        expect(stopped?.["version"]).toBe(2);
        expect(stopped?.["ended_at"]).not.toBeNull();
        await op("session_undo", { id: session["id"], version: 2 });
        const [restored] =
          await tx`select version,ended_at from public.ff_daily_sessions where id=${session["id"]}`;
        expect(restored?.["version"]).toBe(3);
        expect(restored?.["ended_at"]).toBeNull();
        await op("queue_add", { nick });
        expect(
          (await tx`select count(*)::int as count from public.ff_waitlist where nick=${nick}`)[0]?.[
            "count"
          ],
        ).toBe(1);
        expect(
          (await tx`select nick_key from public.ff_waitlist where nick=${nick}`)[0]?.["nick_key"],
        ).toBe(nick.toLowerCase());
        const [registration] =
          await tx`insert into public.ff_registrations(user_id,nick,phone,auto_on,vip,consent) values(${crypto.randomUUID()},${`Registration-${suffix}`},'5511987654321',false,0,true) returning *`;
        if (!registration) throw new Error("Missing transaction registration");
        await op("registration_update", {
          id: registration["id"],
          version: 1,
          phone: registration["phone"],
          auto_on: false,
          vip: 0,
          status: "Ativo",
        });
        await op("registration_update", {
          id: registration["id"],
          version: 2,
          phone: registration["phone"],
          auto_on: false,
          vip: 0,
          status: "Ativo",
        });
        const linked =
          await tx`select id from public.ff_participants where registration_id=${registration["id"]}`;
        expect(linked).toHaveLength(1);
        expect(
          (
            await tx`select count(*)::int as count from public.ff_daily_sessions where participant_id=${linked[0]?.["id"]}`
          )[0]?.["count"],
        ).toBe(0);
        const [permissions] =
          await tx`select has_column_privilege('authenticated','public.ff_registrations','phone','SELECT') as phone, has_column_privilege('authenticated','public.ff_registrations','consent','SELECT') as consent, has_function_privilege('anon','public.ff_admin_operation(text,jsonb)','EXECUTE') as admin, has_function_privilege('authenticated','public.ff_admin_operation(text,jsonb)','EXECUTE') as player_admin`;
        expect(permissions).toEqual({
          phone: false,
          consent: false,
          admin: false,
          player_admin: false,
        });
        await op("registration_delete", { id: registration["id"], version: 3 });
        expect(
          (
            await tx`select count(*)::int as count from public.ff_participants where id=${linked[0]?.["id"]}`
          )[0]?.["count"],
        ).toBe(1);
        throw rolledBack;
      });
    } catch (error) {
      if (error !== rolledBack) throw error;
    } finally {
      await db.end();
    }
  },
  30000,
);
