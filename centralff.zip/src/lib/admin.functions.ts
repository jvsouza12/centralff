import { createServerFn } from "@tanstack/react-start";
import {
  getCookie,
  setCookie,
  deleteCookie,
  getRequestIP,
  getRequestHeader,
  setResponseStatus,
} from "@tanstack/react-start/server";
import { z } from "zod";
import {
  adminCookie,
  cookieOptions,
  privateResponse,
  readAdminSession,
  sessionHash,
} from "./admin-session.server";

function safeEqual(a: string, b: string) {
  const x = new TextEncoder().encode(a),
    y = new TextEncoder().encode(b);
  let diff = x.length ^ y.length;
  for (let i = 0; i < Math.max(x.length, y.length); i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}
export const adminLogin = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({ login: z.string().trim().min(1).max(64), password: z.string().min(1).max(128) })
      .parse(input),
  )
  .handler(async ({ data }) => {
    privateResponse();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // The managed edge supplies cf-connecting-ip; do not trust arbitrary X-Forwarded-For chains.
    const ip = await sessionHash(
      getRequestHeader("cf-connecting-ip") ?? getRequestIP({ xForwardedFor: false }) ?? "unknown",
    );
    const login = process.env["ADMIN_LOGIN"] ?? "",
      pass = process.env["ADMIN_PASSWORD"] ?? "";
    const valid =
      Boolean(login && pass) && safeEqual(data.login, login) && safeEqual(data.password, pass);
    const attempt = await supabaseAdmin.rpc("ff_record_login_attempt", {
      p_ip: ip,
      p_success: valid,
    });
    if (attempt.error) return { ok: false as const, error: "Acesso temporariamente indisponível." };
    if (!attempt.data) {
      setResponseStatus(429);
      return { ok: false as const, error: "Muitas tentativas. Aguarde 15 minutos." };
    }
    if (!valid) return { ok: false as const, error: "Credenciais inválidas." };
    const token = Array.from(crypto.getRandomValues(new Uint8Array(32)), (b) =>
      b.toString(16).padStart(2, "0"),
    ).join("");
    const inserted = await supabaseAdmin
      .from("ff_admin_sessions")
      .insert({
        token_hash: await sessionHash(token),
        login,
        expires_at: new Date(Date.now() + 8 * 3600_000).toISOString(),
      });
    if (inserted.error) return { ok: false as const, error: "Não foi possível iniciar a sessão." };
    await supabaseAdmin
      .from("ff_admin_sessions")
      .delete()
      .lt("expires_at", new Date().toISOString());
    setCookie(adminCookie, token, cookieOptions());
    return { ok: true as const };
  });
export const getAdminSession = createServerFn({ method: "GET" }).handler(async () =>
  readAdminSession(),
);
export const adminLogout = createServerFn({ method: "POST" }).handler(async () => {
  privateResponse();
  const token = getCookie(adminCookie);
  if (token) {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const result = await supabaseAdmin
      .from("ff_admin_sessions")
      .delete()
      .eq("token_hash", await sessionHash(token));
    if (result.error) throw new Error("Não foi possível encerrar a sessão. Tente novamente.");
  }
  deleteCookie(adminCookie, cookieOptions());
  return { ok: true };
});
