// Relatório de erros próprio do projeto: registra no console e (opcionalmente)
// em um coletor configurado pelo administrador via VITE_ERROR_ENDPOINT.
// Nenhum dado é enviado a serviços de terceiros por padrão.

type ErrorOptions = {
  mechanism?: "manual" | "onerror" | "unhandledrejection" | "react_error_boundary";
  handled?: boolean;
  severity?: "error" | "warning" | "info";
};

declare global {
  interface Window {
    __appErrorReporter?: {
      track?: (event: string, properties?: Record<string, unknown>) => string | null;
      captureException?: (
        error: unknown,
        context?: Record<string, unknown>,
        options?: ErrorOptions,
      ) => void;
    };
  }
}

const ENDPOINT = (import.meta.env["VITE_ERROR_ENDPOINT"] as string | undefined) ?? "";

export function reportAppError(error: unknown, context: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;
  const payload = {
    message: describeThrown(error),
    stack: error instanceof Error ? error.stack : undefined,
    route: window.location.pathname,
    at: new Date().toISOString(),
    ...context,
  };
  console.error("[app-error]", payload);
  window.__appErrorReporter?.captureException?.(error, payload, {
    mechanism: "react_error_boundary",
    handled: false,
    severity: "error",
  });
  if (!ENDPOINT) return;
  try {
    void fetch(ENDPOINT, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      keepalive: true,
    }).catch(() => undefined);
  } catch {
    /* o relatório nunca deve interromper a interface */
  }
}

const MAX_SERIALIZED_LENGTH = 2000;

// Loaders e server functions lançam Response e objetos simples; String() os
// reduziria a "[object ...]", então extraímos a mensagem útil.
function describeThrown(error: unknown): string {
  if (error instanceof Response) {
    return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
  }
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  const { message } = (error ?? {}) as { message?: unknown };
  if (typeof message === "string" && message.length > 0) return message;
  try {
    return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
  } catch {
    return String(error);
  }
}
