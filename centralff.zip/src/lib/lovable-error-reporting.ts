// DESATIVADO — substituído por src/lib/error-reporting.ts, que registra erros
// localmente (e, se o administrador configurar VITE_ERROR_ENDPOINT, no coletor
// próprio). Nenhuma telemetria do Lovable é utilizada.
export { reportAppError as reportLovableError } from "./error-reporting";

declare global {
  interface Window {
    __lovableEvents?: unknown;
    __lovableReportRuntimeError?: unknown;
  }
}

