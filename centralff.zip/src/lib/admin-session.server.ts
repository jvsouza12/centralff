import { getCookie, getRequest, getRequestHeader, setResponseHeader, setResponseStatus } from '@tanstack/react-start/server'

export const adminCookie = 'ff_admin'
export async function sessionHash(token: string) {
  const secret = process.env['ADMIN_SESSION_SECRET']
  if (!secret) throw new Error('Acesso administrativo indisponível.')
  const enc = new TextEncoder()
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  const hash = await crypto.subtle.sign('HMAC', key, enc.encode(token))
  return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, '0')).join('')
}
export function privateResponse() { setResponseHeader('Cache-Control', 'no-store, private') }
export function cookieOptions() {
  const url = new URL(getRequest().url)
  const secure = url.protocol === 'https:' || getRequestHeader('x-forwarded-proto')?.split(',')[0]?.trim() === 'https'
  return { httpOnly: true, secure, sameSite: secure ? 'none' as const : 'lax' as const, path: '/', maxAge: 8 * 3600 }
}
export async function readAdminSession() {
  privateResponse()
  const raw = getCookie(adminCookie)
  if (!raw || !/^[a-f0-9]{64}$/.test(raw)) return null
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { data, error } = await supabaseAdmin.from('ff_admin_sessions').select('login,expires_at').eq('token_hash', await sessionHash(raw)).gt('expires_at', new Date().toISOString()).maybeSingle()
  if (error) throw new Error('Não foi possível verificar o acesso administrativo.')
  return data ? { login: data.login } : null
}
export async function requireAdmin() {
  const session = await readAdminSession()
  if (!session) { setResponseStatus(401); throw new Error('Acesso administrativo necessário.') }
  return session
}