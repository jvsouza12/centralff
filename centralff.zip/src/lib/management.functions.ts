import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requireAdmin, privateResponse } from "./admin-session.server";
import {
  civilDay,
  dateSchema,
  nickSchema,
  normalizePhone,
  registrationSchema,
  statuses,
} from "./operations";

export const getOwnRegistration = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    privateResponse();
    const { data, error } = await context.supabase
      .from("ff_registrations")
      .select("id,nick,auto_on,vip,status,submitted_at")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error("Não foi possível carregar seu cadastro.");
    return data;
  });
export const submitRegistration = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => registrationSchema.parse(input))
  .handler(async ({ context, data }) => {
    privateResponse();
    const result = await context.supabase.rpc("ff_submit_registration", {
      p_nick: data.nick,
      p_phone: data.phone,
      p_auto: data.auto_on,
      p_vip: data.vip,
      p_consent: data.consent,
    });
    if (result.error)
      throw new Error(
        "Não foi possível receber o envio. Confira os dados e aguarde 30 segundos para tentar novamente.",
      );
    return { received: true };
  });
const readSchema = z.object({
  day: dateSchema,
  search: z.string().max(80).default(""),
  status: z.enum(statuses).optional(),
  page: z.number().int().min(1).max(100000).default(1),
});
export const getManagement = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => readSchema.parse(input))
  .handler(async ({ data }) => {
    await requireAdmin();
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    let query = db
      .from("ff_registrations")
      .select("id,nick,auto_on,vip,status,version,submitted_at", { count: "exact" })
      .order("submitted_at", { ascending: false })
      .range((data.page - 1) * 20, data.page * 20 - 1);
    if (data.search)
      query = query.ilike("nick", `%${data.search.replace(/[\\%_]/g, (c) => `\\${c}`)}%`);
    if (data.status) query = query.eq("status", data.status);
    const [registrations, participants, sessions, notes, queue, ranking, active] =
      await Promise.all([
        query,
        db.from("ff_participants").select("*").order("created_at"),
        db.from("ff_daily_sessions").select("*").eq("day", data.day).order("started_at"),
        db.from("ff_daily_notes").select("*").eq("day", data.day),
        db.from("ff_waitlist").select("*").order("position"),
        db
          .from("ff_registrations")
          .select("id,nick,vip")
          .gt("vip", 0)
          .order("vip", { ascending: false })
          .order("nick"),
        db.from("ff_daily_sessions").select("*").is("ended_at", null),
      ]);
    if ([registrations, participants, sessions, notes, queue, ranking, active].some((r) => r.error))
      throw new Error("Falha na sincronização. Seus dados foram preservados.");
    return {
      registrations: registrations.data ?? [],
      count: registrations.count ?? 0,
      participants: participants.data ?? [],
      sessions: sessions.data ?? [],
      notes: notes.data ?? [],
      queue: queue.data ?? [],
      ranking: ranking.data ?? [],
      active: active.data ?? [],
      today: civilDay(),
      synced_at: new Date().toISOString(),
    };
  });
const id = z.string().uuid(),
  version = z.number().int().min(1);
const operationSchema = z.discriminatedUnion("command", [
  z.object({
    command: z.literal("registration_update"),
    id,
    version,
    phone: z.string().max(30).transform(normalizePhone),
    auto_on: z.boolean(),
    vip: z.number().int().min(0).max(100),
    status: z.enum(statuses),
  }),
  z.object({ command: z.literal("registration_delete"), id, version }),
  z.object({ command: z.literal("participant_add"), nick: nickSchema }),
  z.object({ command: z.literal("session_start"), participant_id: id, day: dateSchema }),
  z.object({ command: z.literal("session_stop"), id, version }),
  z.object({ command: z.literal("session_undo"), id, version }),
  z.object({
    command: z.literal("daily_note"),
    participant_id: id,
    day: dateSchema,
    note: z.string().max(2000),
    correction_seconds: z.number().int().min(0).max(86400),
    version: z.number().int().min(0),
  }),
  z.object({ command: z.literal("queue_add"), nick: nickSchema }),
  z.object({ command: z.literal("queue_remove"), id, version }),
  z.object({ command: z.literal("queue_move"), id, version, direction: z.enum(["up", "down"]) }),
  z.object({
    command: z.literal("incident_add"),
    registration_id: id,
    happened_on: dateSchema,
    description: z.string().trim().min(1).max(2000),
    evidence: z.string().max(2000),
    request_key: id,
  }),
]);
export type ManagementOperation = z.input<typeof operationSchema>;
export const getRegistrationDetails = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ id }).parse(input))
  .handler(async ({ data }) => {
    await requireAdmin();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const result = await supabaseAdmin
      .from("ff_registrations")
      .select("*")
      .eq("id", data.id)
      .single();
    if (result.error || !result.data) throw new Error("Ficha não disponível. Sincronize a lista.");
    return result.data;
  });
export const manage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => operationSchema.parse(input))
  .handler(async ({ data }) => {
    await requireAdmin();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { command, ...payload } = data;
    const result = await supabaseAdmin.rpc("ff_admin_operation", { command, payload });
    if (result.error) {
      if (result.error.code === "23505") throw new Error("Este nick já está nesta lista.");
      if (result.error.code === "P0001") throw new Error(result.error.message);
      throw new Error("Não foi possível salvar. Confira os campos e sincronize a tela.");
    }
    return { ok: true };
  });
export const getPrivateHistory = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        participant_id: id.optional(),
        registration_id: id.optional(),
        page: z.number().int().min(1).max(100000).default(1),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    await requireAdmin();
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    const from = (data.page - 1) * 20;
    if (data.participant_id) {
      const [sessions, notes] = await Promise.all([
        db
          .from("ff_daily_sessions")
          .select("*", { count: "exact" })
          .eq("participant_id", data.participant_id)
          .order("started_at", { ascending: false })
          .range(from, from + 19),
        db
          .from("ff_daily_notes")
          .select("*")
          .eq("participant_id", data.participant_id)
          .order("day", { ascending: false }),
      ]);
      if (sessions.error || notes.error) throw new Error("Não foi possível carregar o histórico.");
      return {
        sessions: sessions.data ?? [],
        notes: notes.data ?? [],
        incidents: [],
        count: sessions.count ?? 0,
      };
    }
    if (!data.registration_id) throw new Error("Selecione um jogador.");
    const result = await db
      .from("ff_incidents")
      .select("*", { count: "exact" })
      .eq("registration_id", data.registration_id)
      .order("happened_on", { ascending: false })
      .range(from, from + 19);
    if (result.error) throw new Error("Não foi possível carregar as ocorrências.");
    return { sessions: [], notes: [], incidents: result.data ?? [], count: result.count ?? 0 };
  });
