import { z } from 'zod'

export const statuses = ['Aguardando confirmação', 'Ativo', 'Advertido', 'Suspenso', 'Banido'] as const
export const roomName = '3000% BOT SENSATION 24/48 ADD'
export const groupRules = [
  'Manter o NickName correto e informado.',
  'Não sair da sala na hora da partida.',
  'Respeitar todos os jogadores.',
  'O objetivo é fomentar XP em parceria.',
  'O descumprimento pode resultar em banimento das salas e do grupo de WhatsApp.',
] as const
export const nickSchema = z.string().min(1).max(80).refine(value => value.trim().length > 0, 'Informe o nick.')
export function normalizePhone(value: string) {
  const digits = value.replace(/\D/g, '')
  const phone = digits.length === 11 ? `55${digits}` : digits
  if (!/^55[1-9][0-9]9[0-9]{8}$/.test(phone)) throw new Error('Informe um celular brasileiro com DDD e 9 dígitos.')
  const ddd = Number(phone.slice(2, 4))
  const validDDD = [11,12,13,14,15,16,17,18,19,21,22,24,27,28,31,32,33,34,35,37,38,41,42,43,44,45,46,47,48,49,51,53,54,55,61,62,63,64,65,66,67,68,69,71,73,74,75,77,79,81,82,83,84,85,86,87,88,89,91,92,93,94,95,96,97,98,99]
  if (!validDDD.includes(ddd)) throw new Error('DDD brasileiro inválido.')
  return phone
}
export const registrationSchema = z.object({
  nick: nickSchema, phone: z.string().max(30).transform(normalizePhone),
  auto_on: z.boolean(), vip: z.number().int().min(0).max(100), consent: z.literal(true),
})
export function civilDay(now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now)
  const get = (type: string) => parts.find(p => p.type === type)?.value ?? ''
  return `${get('year')}-${get('month')}-${get('day')}`
}
export function durationSeconds(start: string, end: string | null, now: number) {
  return Math.max(0, Math.floor(((end ? new Date(end).getTime() : now) - new Date(start).getTime()) / 1000))
}
export function clock(seconds: number) {
  const s = Math.max(0, Math.floor(seconds))
  return `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`
}
export function compareVIP(a: { nick: string; vip: number }, b: { nick: string; vip: number }) {
  return b.vip - a.vip || a.nick.localeCompare(b.nick, 'pt-BR') || (a.nick < b.nick ? -1 : a.nick > b.nick ? 1 : 0)
}
export const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(value => {
  const date = new Date(`${value}T12:00:00Z`)
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value
}, 'Data inválida.')
export const DISCORD_INVITE = "https://discord.gg/PMPwacEBS7";
