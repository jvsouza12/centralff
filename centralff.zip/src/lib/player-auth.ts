import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";

/**
 * Autenticador próprio do projeto (substitui o antigo login do Lovable Cloud).
 * Login por nick + e-mail + senha, direto no projeto Supabase do clã —
 * nenhum provedor intermediário é usado.
 */

const emailField = z
  .string()
  .trim()
  .min(5, "Informe um e-mail válido.")
  .max(160, "E-mail muito longo.")
  .email("Informe um e-mail válido.");
const passwordField = z
  .string()
  .min(8, "Use pelo menos 8 caracteres na senha.")
  .max(72, "A senha deve ter no máximo 72 caracteres.");
const nickField = z
  .string()
  .trim()
  .min(1, "Informe o nick usado no CrossFire.")
  .max(80, "O nick deve ter até 80 caracteres.");

export const signInSchema = z.object({
  email: emailField,
  password: z.string().min(1, "Informe sua senha."),
});
export const signUpSchema = z.object({ nick: nickField, email: emailField, password: passwordField });
export const resetSchema = z.object({ email: emailField });
export const newPasswordSchema = z.object({ password: passwordField });
export const resendConfirmationSchema = z.object({ email: emailField });

export type PlayerAuthResult =
  | { ok: true; message?: string; needsEmailConfirmation?: boolean }
  | { ok: false; error: string };

const AUTH_MESSAGES: ReadonlyArray<readonly [RegExp, string]> = [
  [/invalid login credentials/i, "E-mail ou senha incorretos."],
  [/email not confirmed/i, "Confirme o e-mail de ativação antes de entrar."],
  [/user already registered|already been registered/i, "Este e-mail já possui acesso. Use a aba Entrar."],
  [/password should be at least/i, "A senha é curta demais. Use pelo menos 8 caracteres."],
  [/new password should be different/i, "A nova senha precisa ser diferente da anterior."],
  [/unable to validate email|invalid format|invalid email/i, "Informe um e-mail válido."],
  [/email rate limit exceeded|over_email_send_rate_limit/i, "Muitas solicitações de e-mail. Aguarde alguns minutos."],
  [/for security purposes/i, "Aguarde alguns segundos antes de tentar novamente."],
  [/signups? not allowed|signup is disabled/i, "Novo acesso desativado no momento. Fale com um administrador."],
  [/token has expired or is invalid|invalid or expired/i, "Link expirado. Solicite um novo e-mail de redefinição."],
  [/auth session missing|refresh token/i, "Sessão não encontrada. Entre novamente."],
  [/failed to fetch|network ?error|load failed/i, "Falha de conexão. Verifique sua internet."],
  [/already confirmed|user already confirmed/i, "Este acesso já está ativo. Use a aba Entrar."],
  [/user not found/i, "Não encontramos um acesso com este e-mail."],
];

export function authErrorMessage(
  raw: unknown,
  fallback = "Não foi possível concluir agora. Tente novamente.",
): string {
  const text =
    raw instanceof Error
      ? raw.message
      : typeof raw === "string"
        ? raw
        : typeof (raw as { message?: unknown } | null)?.message === "string"
          ? String((raw as { message: string }).message)
          : "";
  for (const [pattern, message] of AUTH_MESSAGES) if (pattern.test(text)) return message;
  return fallback;
}

function firstIssue(error: z.ZodError): string {
  return error.issues[0]?.message ?? "Confira os dados informados.";
}

function origin(): string | undefined {
  return typeof window === "undefined" ? undefined : window.location.origin;
}

export async function signInPlayer(input: unknown): Promise<PlayerAuthResult> {
  const parsed = signInSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  try {
    const { error } = await supabase.auth.signInWithPassword({
      email: parsed.data.email,
      password: parsed.data.password,
    });
    if (error) return { ok: false, error: authErrorMessage(error.message) };
    clearRecoveryIntent();
    return { ok: true };
  } catch (error) {
    return { ok: false, error: authErrorMessage(error) };
  }
}

export async function signUpPlayer(input: unknown): Promise<PlayerAuthResult> {
  const parsed = signUpSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  try {
    const { data, error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        ...(origin() ? { emailRedirectTo: origin() as string } : {}),
        data: { nick: parsed.data.nick, full_name: parsed.data.nick },
      },
    });
    if (error) return { ok: false, error: authErrorMessage(error.message) };
    // O Supabase devolve um usuário sem identidades quando o e-mail já existe.
    if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
      return { ok: false, error: "Este e-mail já possui acesso. Use a aba Entrar." };
    }
    clearRecoveryIntent();
    return { ok: true, needsEmailConfirmation: !data.session };
  } catch (error) {
    return { ok: false, error: authErrorMessage(error) };
  }
}

export async function signOutPlayer(): Promise<PlayerAuthResult> {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) return { ok: false, error: authErrorMessage(error.message) };
    return { ok: true };
  } catch (error) {
    return { ok: false, error: authErrorMessage(error) };
  }
}

export async function requestPlayerPasswordReset(input: unknown): Promise<PlayerAuthResult> {
  const parsed = resetSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  const target = origin();
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
      ...(target ? { redirectTo: `${target}/redefinir-senha` } : {}),
    });
    if (error) return { ok: false, error: authErrorMessage(error.message) };
    markRecoveryIntent();
    return {
      ok: true,
      message: "Se este e-mail tiver acesso, o link de redefinição chegará em instantes.",
    };
  } catch (error) {
    return { ok: false, error: authErrorMessage(error) };
  }
}

export async function setNewPlayerPassword(input: unknown): Promise<PlayerAuthResult> {
  const parsed = newPasswordSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  try {
    const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
    if (error) return { ok: false, error: authErrorMessage(error.message) };
    clearRecoveryIntent();
    return { ok: true, message: "Senha atualizada. Use a nova senha no próximo acesso." };
  } catch (error) {
    return { ok: false, error: authErrorMessage(error) };
  }
}

/** Reenvia o e-mail de ativação de um acesso ainda não confirmado. */
export async function resendPlayerConfirmation(input: unknown): Promise<PlayerAuthResult> {
  const parsed = resendConfirmationSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
  const target = origin();
  try {
    const { error } = await supabase.auth.resend({
      type: "signup",
      email: parsed.data.email,
      ...(target ? { options: { emailRedirectTo: target } } : {}),
    });
    if (error) return { ok: false, error: authErrorMessage(error.message) };
    return { ok: true, message: `Enviamos um novo e-mail de ativação para ${parsed.data.email}.` };
  } catch (error) {
    return { ok: false, error: authErrorMessage(error) };
  }
}

export type AuthLinkFeedback =
  | { kind: "error"; message: string }
  | { kind: "confirmed"; message: string }
  | { kind: "recovery"; message: string };

const LINK_ERROR_MESSAGES: ReadonlyArray<readonly [RegExp, string]> = [
  [/expired|invalid|otp_expired/i, "Este link expirou ou já foi usado. Solicite um novo e-mail."],
  [/access_denied|denied/i, "O acesso por este link foi negado. Solicite um novo e-mail."],
];

/**
 * Indica se a URL atual traz parâmetros de link de e-mail. Nesses casos o portal
 * não deve redirecionar automaticamente: a página precisa tratar confirmação ou
 * redefinição antes de liberar a área do jogador.
 */
export function hasAuthLinkParams(raw?: string): boolean {
  const href = raw ?? (typeof window === "undefined" ? "" : window.location.href);
  if (!href) return false;
  let url: URL;
  try {
    url = new URL(href, "https://portal.invalid");
  } catch {
    return false;
  }
  const hash = new URLSearchParams(url.hash.replace(/^#/, ""));
  const keys = ["access_token", "refresh_token", "code", "error", "error_code", "type", "token_hash"];
  return keys.some((key) => Boolean(url.searchParams.get(key) || hash.get(key)));
}

/**
 * Marca, no navegador que pediu a recuperação, que o próximo acesso autenticado
 * veio de um link de redefinição. Necessário porque no fluxo PKCE o link chega
 * apenas como `?code=…`, sem dizer o tipo — e nesse caso a área do jogador não
 * deve abrir antes de o usuário definir a nova senha.
 */
const RECOVERY_INTENT_KEY = "ff-recovery-intent";
const RECOVERY_INTENT_MAX_AGE = 15 * 60_000;

function recoveryIntentStore(): Storage | undefined {
  try {
    return typeof window === "undefined" ? undefined : window.sessionStorage;
  } catch {
    return undefined;
  }
}

export function markRecoveryIntent() {
  try {
    recoveryIntentStore()?.setItem(RECOVERY_INTENT_KEY, String(Date.now()));
  } catch {
    /* marcação é apenas uma conveniência de fluxo */
  }
}

export function hasRecoveryIntent(maxAgeMs = RECOVERY_INTENT_MAX_AGE): boolean {
  try {
    const raw = recoveryIntentStore()?.getItem(RECOVERY_INTENT_KEY);
    if (!raw) return false;
    const at = Number(raw);
    if (!Number.isFinite(at) || Date.now() - at > maxAgeMs) {
      clearRecoveryIntent();
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function clearRecoveryIntent() {
  try {
    recoveryIntentStore()?.removeItem(RECOVERY_INTENT_KEY);
  } catch {
    /* ignora ambientes sem storage */
  }
}

/**
 * Lê o que o provedor devolve na URL após cliques em links de e-mail
 * (confirmação de cadastro, recuperação de senha e falhas). Somente
 * parâmetros de controle; nenhum token é exibido ou registrado.
 */
export function readAuthLinkFeedback(raw?: string): AuthLinkFeedback | null {
  const href = raw ?? (typeof window === "undefined" ? "" : window.location.href);
  if (!href) return null;
  let url: URL;
  try {
    url = new URL(href, "https://portal.invalid");
  } catch {
    return null;
  }
  const hash = new URLSearchParams(url.hash.replace(/^#/, ""));
  const pick = (key: string) => hash.get(key) ?? url.searchParams.get(key) ?? "";
  const type = pick("type").toLowerCase();
  const code = pick("error_code") || pick("error");
  const description = pick("error_description");
  if (code || description) {
    const text = `${code} ${description}`;
    for (const [pattern, message] of LINK_ERROR_MESSAGES) {
      if (pattern.test(text)) return { kind: "error", message };
    }
    return {
      kind: "error",
      message: "Não foi possível concluir pelo link recebido. Solicite um novo e-mail e tente novamente.",
    };
  }
  if (type === "recovery") {
    return { kind: "recovery", message: "Link de redefinição recebido. Defina sua nova senha." };
  }
  if ((type === "signup" || type === "email" || type === "magiclink") && pick("access_token")) {
    return { kind: "confirmed", message: "E-mail confirmado. Bem-vindo ao portal do jogador." };
  }
  return null;
}
