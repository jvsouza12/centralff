CREATE TABLE public.admin_login_attempts (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), ip text NOT NULL, success boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.admin_login_attempts TO service_role;
ALTER TABLE public.admin_login_attempts ENABLE ROW LEVEL SECURITY;
CREATE INDEX admin_login_attempts_ip_time ON public.admin_login_attempts (ip, created_at DESC);