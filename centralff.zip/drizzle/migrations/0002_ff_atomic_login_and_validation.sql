CREATE FUNCTION public.ff_record_login_attempt(p_ip text,p_success boolean) RETURNS boolean LANGUAGE plpgsql SET search_path=public AS $$
DECLARE failures integer;
BEGIN
PERFORM pg_advisory_xact_lock(hashtextextended(p_ip,100));
SELECT count(*) INTO failures FROM admin_login_attempts WHERE ip=p_ip AND success=false AND created_at >= clock_timestamp()-interval '15 minutes';
IF failures>=5 THEN RETURN false; END IF;
INSERT INTO admin_login_attempts(ip,success) VALUES(p_ip,p_success);
DELETE FROM admin_login_attempts WHERE created_at<now()-interval '30 days';
DELETE FROM ff_admin_sessions WHERE expires_at<now();
RETURN true;
END $$;
REVOKE ALL ON FUNCTION public.ff_record_login_attempt(text,boolean) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.ff_record_login_attempt(text,boolean) TO service_role;
CREATE FUNCTION public.ff_validate_registration_fields() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
DECLARE ddd integer;
BEGIN
ddd := substring(NEW.phone from 3 for 2)::integer;
IF NOT (ddd=ANY(ARRAY[11,12,13,14,15,16,17,18,19,21,22,24,27,28,31,32,33,34,35,37,38,41,42,43,44,45,46,47,48,49,51,53,54,55,61,62,63,64,65,66,67,68,69,71,73,74,75,77,79,81,82,83,84,85,86,87,88,89,91,92,93,94,95,96,97,98,99])) THEN RAISE EXCEPTION 'DDD brasileiro inválido'; END IF;
IF btrim(NEW.nick)='' THEN RAISE EXCEPTION 'Informe o nick'; END IF;
RETURN NEW;
END $$;
CREATE TRIGGER ff_registration_validation BEFORE INSERT OR UPDATE ON public.ff_registrations FOR EACH ROW EXECUTE FUNCTION public.ff_validate_registration_fields();
CREATE FUNCTION public.ff_validate_daily_note() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
IF NEW.day > (now() AT TIME ZONE 'America/Sao_Paulo')::date THEN RAISE EXCEPTION 'Data futura não permitida'; END IF;
IF char_length(NEW.note)>2000 THEN RAISE EXCEPTION 'Observação muito longa'; END IF;
RETURN NEW;
END $$;
CREATE TRIGGER ff_daily_note_validation BEFORE INSERT OR UPDATE ON public.ff_daily_notes FOR EACH ROW EXECUTE FUNCTION public.ff_validate_daily_note();