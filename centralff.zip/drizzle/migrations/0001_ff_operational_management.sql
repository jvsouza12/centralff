CREATE TABLE public.ff_admin_sessions (token_hash text PRIMARY KEY, login text NOT NULL, expires_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ff_admin_sessions TO service_role;
ALTER TABLE public.ff_admin_sessions ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.ff_registrations (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL UNIQUE, nick text NOT NULL CHECK (char_length(nick) BETWEEN 1 AND 80), nick_key text GENERATED ALWAYS AS (lower(normalize(nick, NFKC))) STORED UNIQUE, phone text NOT NULL CHECK (phone ~ '^55[1-9][0-9]9[0-9]{8}$'), auto_on boolean NOT NULL, vip integer NOT NULL CHECK (vip BETWEEN 0 AND 100), consent boolean NOT NULL CHECK (consent), consent_at timestamptz NOT NULL DEFAULT now(), status text NOT NULL DEFAULT 'Aguardando confirmação' CHECK (status IN ('Aguardando confirmação','Ativo','Advertido','Suspenso','Banido')), version integer NOT NULL DEFAULT 1, submitted_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT (id,user_id,nick,auto_on,vip,status,version,submitted_at) ON public.ff_registrations TO authenticated;
GRANT ALL ON public.ff_registrations TO service_role;
ALTER TABLE public.ff_registrations ENABLE ROW LEVEL SECURITY;
CREATE POLICY own_registration ON public.ff_registrations FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE TABLE public.ff_participants (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), registration_id uuid UNIQUE REFERENCES public.ff_registrations(id) ON DELETE SET NULL, nick text NOT NULL CHECK (char_length(nick) BETWEEN 1 AND 80), nick_key text GENERATED ALWAYS AS (lower(normalize(nick, NFKC))) STORED UNIQUE, created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ff_participants TO service_role;
ALTER TABLE public.ff_participants ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.ff_daily_sessions (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), participant_id uuid NOT NULL REFERENCES public.ff_participants(id), day date NOT NULL, started_at timestamptz NOT NULL DEFAULT now(), ended_at timestamptz, version integer NOT NULL DEFAULT 1, CHECK (ended_at IS NULL OR ended_at >= started_at));
GRANT ALL ON public.ff_daily_sessions TO service_role;
ALTER TABLE public.ff_daily_sessions ENABLE ROW LEVEL SECURITY;
CREATE UNIQUE INDEX ff_one_open_session ON public.ff_daily_sessions(participant_id) WHERE ended_at IS NULL;
CREATE INDEX ff_daily_date ON public.ff_daily_sessions(day, participant_id);
CREATE TABLE public.ff_daily_notes (participant_id uuid NOT NULL REFERENCES public.ff_participants(id), day date NOT NULL, note text NOT NULL DEFAULT '', correction_seconds integer NOT NULL DEFAULT 0 CHECK (correction_seconds BETWEEN 0 AND 86400), version integer NOT NULL DEFAULT 1, PRIMARY KEY (participant_id,day));
GRANT ALL ON public.ff_daily_notes TO service_role;
ALTER TABLE public.ff_daily_notes ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.ff_waitlist (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), nick text NOT NULL CHECK (char_length(nick) BETWEEN 1 AND 80), nick_key text GENERATED ALWAYS AS (lower(normalize(nick, NFKC))) STORED UNIQUE, position bigint GENERATED ALWAYS AS IDENTITY, version integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ff_waitlist TO service_role;
ALTER TABLE public.ff_waitlist ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.ff_incidents (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), registration_id uuid NOT NULL REFERENCES public.ff_registrations(id) ON DELETE CASCADE, happened_on date NOT NULL, description text NOT NULL CHECK (char_length(description) BETWEEN 1 AND 2000), evidence text NOT NULL DEFAULT '' CHECK (char_length(evidence) <= 2000), request_key uuid NOT NULL UNIQUE, created_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ff_incidents TO service_role;
ALTER TABLE public.ff_incidents ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.ff_submission_limits (user_id uuid PRIMARY KEY, last_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.ff_submission_limits TO service_role;
ALTER TABLE public.ff_submission_limits ENABLE ROW LEVEL SECURITY;
CREATE FUNCTION public.ff_submit_registration(p_nick text,p_phone text,p_auto boolean,p_vip integer,p_consent boolean) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE previous_at timestamptz;
BEGIN
IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Acesso não autorizado'; END IF;
IF p_nick IS NULL OR char_length(p_nick) NOT BETWEEN 1 AND 80 OR btrim(p_nick) = '' OR p_phone IS NULL OR p_phone !~ '^55[1-9][0-9]9[0-9]{8}$' OR p_auto IS NULL OR p_vip IS NULL OR p_vip NOT BETWEEN 0 AND 100 OR p_consent IS DISTINCT FROM true THEN RAISE EXCEPTION 'Dados inválidos'; END IF;
PERFORM pg_advisory_xact_lock(hashtextextended(auth.uid()::text, 0));
SELECT last_at INTO previous_at FROM ff_submission_limits WHERE user_id=auth.uid();
IF previous_at > now()-interval '30 seconds' THEN RAISE EXCEPTION 'Aguarde 30 segundos antes de tentar novamente'; END IF;
INSERT INTO ff_submission_limits(user_id) VALUES (auth.uid()) ON CONFLICT (user_id) DO UPDATE SET last_at=now();
IF EXISTS (SELECT 1 FROM ff_registrations WHERE user_id=auth.uid()) THEN RETURN jsonb_build_object('received',true); END IF;
INSERT INTO ff_registrations(user_id,nick,phone,auto_on,vip,consent) VALUES(auth.uid(),p_nick,p_phone,p_auto,p_vip,p_consent) ON CONFLICT DO NOTHING;
RETURN jsonb_build_object('received',true);
END $$;
REVOKE ALL ON FUNCTION public.ff_submit_registration(text,text,boolean,integer,boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.ff_submit_registration(text,text,boolean,integer,boolean) TO authenticated;
CREATE FUNCTION public.ff_admin_operation(command text, payload jsonb) RETURNS jsonb LANGUAGE plpgsql SET search_path = public AS $$
DECLARE r ff_registrations; s ff_daily_sessions; q ff_waitlist; pid uuid; today date := (now() AT TIME ZONE 'America/Sao_Paulo')::date; chosen date; expected integer; temp_pos bigint; other_id uuid; n text;
BEGIN
IF command IN ('registration_update','registration_delete') THEN
 SELECT * INTO r FROM ff_registrations WHERE id=(payload->>'id')::uuid FOR UPDATE;
 IF r.id IS NULL THEN RAISE EXCEPTION 'Cadastro não encontrado'; END IF;
 IF r.version <> (payload->>'version')::integer THEN RAISE EXCEPTION 'Conflito: atualize a tela antes de salvar'; END IF;
 IF command='registration_delete' THEN DELETE FROM ff_registrations WHERE id=r.id; RETURN jsonb_build_object('ok',true); END IF;
 UPDATE ff_registrations SET phone=payload->>'phone',auto_on=(payload->>'auto_on')::boolean,vip=(payload->>'vip')::integer,status=payload->>'status',version=version+1 WHERE id=r.id;
 IF payload->>'status'='Ativo' THEN
  INSERT INTO ff_participants(registration_id,nick) VALUES(r.id,r.nick) ON CONFLICT(nick_key) DO UPDATE SET registration_id=COALESCE(ff_participants.registration_id,EXCLUDED.registration_id);
 END IF;
ELSIF command='participant_add' THEN
 n:=payload->>'nick'; IF n IS NULL OR btrim(n)='' THEN RAISE EXCEPTION 'Informe o nick'; END IF;
 INSERT INTO ff_participants(nick) VALUES(n);
ELSIF command='session_start' THEN
 pid:=(payload->>'participant_id')::uuid; chosen:=(payload->>'day')::date;
 IF chosen IS DISTINCT FROM today THEN RAISE EXCEPTION 'Sessões reais só podem iniciar na data de hoje'; END IF;
 PERFORM 1 FROM ff_participants WHERE id=pid FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Participante não encontrado'; END IF;
 INSERT INTO ff_daily_sessions(participant_id,day) VALUES(pid,today) ON CONFLICT (participant_id) WHERE ended_at IS NULL DO NOTHING;
ELSIF command IN ('session_stop','session_undo') THEN
 SELECT * INTO s FROM ff_daily_sessions WHERE id=(payload->>'id')::uuid FOR UPDATE;
 IF s.id IS NULL THEN RAISE EXCEPTION 'Sessão não encontrada'; END IF;
 PERFORM 1 FROM ff_participants WHERE id=s.participant_id FOR UPDATE;
 IF command='session_stop' THEN
  IF s.ended_at IS NOT NULL THEN RETURN jsonb_build_object('ok',true); END IF;
  IF s.version <> (payload->>'version')::integer THEN RAISE EXCEPTION 'Conflito de sessão'; END IF;
  UPDATE ff_daily_sessions SET ended_at=now(),version=version+1 WHERE id=s.id;
 ELSE
  IF s.ended_at IS NULL THEN RETURN jsonb_build_object('ok',true); END IF;
  IF s.version <> (payload->>'version')::integer OR now()-s.ended_at > interval '30 seconds' THEN RAISE EXCEPTION 'Prazo de desfazer expirado ou sessão alterada'; END IF;
  IF EXISTS(SELECT 1 FROM ff_daily_sessions WHERE participant_id=s.participant_id AND ended_at IS NULL) THEN RAISE EXCEPTION 'Já existe uma sessão aberta'; END IF;
  UPDATE ff_daily_sessions SET ended_at=NULL,version=version+1 WHERE id=s.id;
 END IF;
ELSIF command='daily_note' THEN
 pid:=(payload->>'participant_id')::uuid; chosen:=(payload->>'day')::date;
 IF chosen > today THEN RAISE EXCEPTION 'Não é permitido registrar data futura'; END IF;
 IF char_length(payload->>'note')>2000 THEN RAISE EXCEPTION 'Observação muito longa'; END IF;
 PERFORM 1 FROM ff_participants WHERE id=pid FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Participante não encontrado'; END IF;
 SELECT version INTO expected FROM ff_daily_notes WHERE participant_id=pid AND day=chosen;
 IF COALESCE(expected,0) <> (payload->>'version')::integer THEN RAISE EXCEPTION 'Conflito: observação atualizada por outro administrador'; END IF;
 INSERT INTO ff_daily_notes(participant_id,day,note,correction_seconds) VALUES(pid,chosen,payload->>'note',(payload->>'correction_seconds')::integer) ON CONFLICT(participant_id,day) DO UPDATE SET note=EXCLUDED.note,correction_seconds=EXCLUDED.correction_seconds,version=ff_daily_notes.version+1;
ELSIF command='queue_add' THEN
 n:=payload->>'nick'; IF n IS NULL OR btrim(n)='' THEN RAISE EXCEPTION 'Informe o nick'; END IF;
 PERFORM pg_advisory_xact_lock(991001);
 INSERT INTO ff_waitlist(nick) VALUES(n);
ELSIF command='queue_remove' THEN
 PERFORM pg_advisory_xact_lock(991001);
 DELETE FROM ff_waitlist WHERE id=(payload->>'id')::uuid AND version=(payload->>'version')::integer;
 IF NOT FOUND THEN RAISE EXCEPTION 'Conflito: fila alterada, atualize a tela'; END IF;
ELSIF command='queue_move' THEN
 PERFORM pg_advisory_xact_lock(991001);
 SELECT * INTO q FROM ff_waitlist WHERE id=(payload->>'id')::uuid FOR UPDATE;
 IF q.id IS NULL OR q.version<>(payload->>'version')::integer THEN RAISE EXCEPTION 'Conflito: fila alterada'; END IF;
 IF payload->>'direction'='up' THEN SELECT id,position INTO other_id,temp_pos FROM ff_waitlist WHERE position<q.position ORDER BY position DESC LIMIT 1; ELSE SELECT id,position INTO other_id,temp_pos FROM ff_waitlist WHERE position>q.position ORDER BY position LIMIT 1; END IF;
 IF other_id IS NOT NULL THEN UPDATE ff_waitlist SET position=q.position,version=version+1 WHERE id=other_id; UPDATE ff_waitlist SET position=temp_pos,version=version+1 WHERE id=q.id; END IF;
ELSIF command='incident_add' THEN
 IF (payload->>'happened_on')::date>today THEN RAISE EXCEPTION 'Ocorrência não pode ser futura'; END IF;
 INSERT INTO ff_incidents(registration_id,happened_on,description,evidence,request_key) VALUES((payload->>'registration_id')::uuid,(payload->>'happened_on')::date,payload->>'description',COALESCE(payload->>'evidence',''),(payload->>'request_key')::uuid) ON CONFLICT(request_key) DO NOTHING;
ELSE RAISE EXCEPTION 'Operação inválida'; END IF;
RETURN jsonb_build_object('ok',true);
END $$;
REVOKE ALL ON FUNCTION public.ff_admin_operation(text,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.ff_admin_operation(text,jsonb) TO service_role;