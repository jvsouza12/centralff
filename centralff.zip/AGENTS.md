<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# AGENTS.md

- Admin auth is separate from player auth: credentials stay in ADMIN_LOGIN/ADMIN_PASSWORD; opaque httpOnly cookie tokens are stored only as keyed hashes in ff_admin_sessions and validated through admin-session.server.ts. Why: secret isolation and revocable sessions.
- Player auth is the project's own authenticator (src/lib/player-auth.ts) using only this project's Supabase email/password provider, with own recovery flow at /redefinir-senha. The Lovable Cloud Auth broker, the preview session broker and Lovable telemetry were removed; session tokens live only in this domain's localStorage. Why: no third-party intermediation of player credentials.
- Player auth covers sign-in, sign-up with activation resend, password recovery by email link, and authenticated password change inside the player area (no email dependency). Email links are classified by hasAuthLinkParams/readAuthLinkFeedback: confirmation opens the player area with a notice, recovery always routes to /redefinir-senha, and a sessionStorage recovery intent covers the PKCE case where the link only carries ?code=. Why: an email link must never open the player area before a new password is set, and SMTP limits must not lock a player out.
- Admin brute-force limit uses an atomic service-role RPC with advisory locking and hashed edge IP; old attempts expire during login. Why: workers have no shared memory and concurrent requests must not bypass limits.
- Player registration uses the authenticated pathless layout and protected bearer server functions; legacy /arena remains client-only and protected. Admin functions independently validate the cookie session on every call. Why: UI guards are not authorization boundaries.
- Operational tables are additive, private and initially empty; service-role transactional RPCs run only after admin session verification, while player submissions derive auth.uid() server-side. Why: privacy, consistency and preservation of legitimate data.
- External CI deploys (e.g. Vercel building the synced GitHub repo) are supported by `nitro: { preset: "vercel" }` in vite.config.ts; the platform build ignores it and stays on Cloudflare. The admin panel and management functions need SUPABASE_SERVICE_ROLE_KEY, which only this platform's runtime injects, so on external hosts they fail while player flows work with the publishable key from the tracked .env. Why: one config serves both targets with a known, tested capability boundary.
- Use TanStack Start and managed Cloud PostgreSQL rather than Express/MySQL/Netlify adapters. Why: this project's fixed runtime does not support replacing its framework or claiming unverified external deployments.
- Keep registration, daily participants and waitlist independent; only explicit admin approval links registration to a participant. Why: registration must never fabricate participation or queue entries.
- Fetch phone and consent only when an admin opens a ficha, and clear private client caches on logout and identity transitions. Why: minimize data exposure and prevent stale account data.
- Pin patched transitive source-map and YAML dependencies through package overrides. Why: fix advisory-reported denial-of-service issues without replacing the managed framework.
